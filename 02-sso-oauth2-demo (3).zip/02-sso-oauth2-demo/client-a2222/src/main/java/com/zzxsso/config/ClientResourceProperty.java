package com.zzxsso.config;

import org.springframework.boot.autoconfigure.security.oauth2.resource.ResourceServerProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.client.token.grant.code.AuthorizationCodeResourceDetails;

import java.util.Map;
@Configuration
@ConfigurationProperties(prefix = "sso")
public class ClientResourceProperty {
    private Map<String,ClientResource>  custom;

    public Map<String, ClientResource> getCustom() {
        return custom;
    }

    public void setCustom(Map<String, ClientResource> custom) {
        this.custom = custom;
    }

    public static class ClientResource {

        public static final String DEFAULT_LOGIN_PATH = "/login";

        /**
         * Path to the login page, i.e. the one that triggers the redirect to the OAuth2
         * Authorization Server.
         */
        private String loginPath;

        public String getLoginPath() {
            return this.loginPath;
        }

        public void setLoginPath(String loginPath) {
            this.loginPath = loginPath;
        }

        @NestedConfigurationProperty
        private AuthorizationCodeResourceDetails client = new AuthorizationCodeResourceDetails();
        @NestedConfigurationProperty
        private ResourceServerProperties resource = new ResourceServerProperties();

        public AuthorizationCodeResourceDetails getClient() {
            return client;
        }

        public ResourceServerProperties getResource() {
            return resource;
        }
    }


}
