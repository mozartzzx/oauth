package com.zzxsso.config;

import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.config.annotation.SecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.ExceptionHandlingConfigurer;
import org.springframework.security.oauth2.client.filter.OAuth2ClientAuthenticationProcessingFilter;
import org.springframework.security.web.DefaultSecurityFilterChain;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;
import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;
import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;
import org.springframework.security.web.util.matcher.MediaTypeRequestMatcher;
import org.springframework.security.web.util.matcher.RequestHeaderRequestMatcher;
import org.springframework.web.accept.ContentNegotiationStrategy;
import org.springframework.web.accept.HeaderContentNegotiationStrategy;

import java.util.Collection;
import java.util.Collections;

public class ZcSsoSecurityConfigurer {

    private static  String DEFAULT_SSO_ENTRYKEY="default";

    private ApplicationContext applicationContext;

    private  ZcOauth2ManagerBuilder zcOauth2ManagerBuilder;

    ZcSsoSecurityConfigurer(ApplicationContext applicationContext,  ZcOauth2ManagerBuilder zcOauth2ManagerBuilder) {

        this.applicationContext = applicationContext;
        this. zcOauth2ManagerBuilder=zcOauth2ManagerBuilder;

    }
    public void configure(HttpSecurity http) throws Exception {
        zcOauth2ManagerBuilder.init();
        ZcAbstractOauth2ManagerConfiguration zcOauth2ManagerConfiguration = applicationContext.getBeanProvider(ZcAbstractOauth2ManagerConfiguration.class).getIfAvailable();
        if(zcOauth2ManagerConfiguration!=null){
            zcOauth2ManagerConfiguration.configer(zcOauth2ManagerBuilder);
        }
        Collection<OAuth2ClientAuthenticationProcessingFilter> machtedFiters = zcOauth2ManagerBuilder.buildMachtedFiters();
         http.apply(new OAuth2ClientAuthenticationConfigurer(machtedFiters));
         if(zcOauth2ManagerBuilder.getClientResourceProperty().getCustom().containsKey(DEFAULT_SSO_ENTRYKEY)){
             addAuthenticationEntryPoint(http,DEFAULT_SSO_ENTRYKEY);
         }
    }

    private void addAuthenticationEntryPoint(HttpSecurity http, String key)
            throws Exception {
        ExceptionHandlingConfigurer<HttpSecurity> exceptions = http.exceptionHandling();
        ContentNegotiationStrategy contentNegotiationStrategy = http
                .getSharedObject(ContentNegotiationStrategy.class);
        if (contentNegotiationStrategy == null) {
            contentNegotiationStrategy = new HeaderContentNegotiationStrategy();
        }
        MediaTypeRequestMatcher preferredMatcher = new MediaTypeRequestMatcher(
                contentNegotiationStrategy, MediaType.APPLICATION_XHTML_XML,
                new MediaType("image", "*"), MediaType.TEXT_HTML, MediaType.TEXT_PLAIN);
        preferredMatcher.setIgnoredMediaTypes(Collections.singleton(MediaType.ALL));
        exceptions.defaultAuthenticationEntryPointFor(
                new LoginUrlAuthenticationEntryPoint(zcOauth2ManagerBuilder.getClientResourceProperty().getCustom().get(key).getLoginPath()),
                preferredMatcher);
        // When multiple entry points are provided the default is the first one
        exceptions.defaultAuthenticationEntryPointFor(
                new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED),
                new RequestHeaderRequestMatcher("X-Requested-With", "XMLHttpRequest"));
    }



    private static class OAuth2ClientAuthenticationConfigurer
            extends SecurityConfigurerAdapter<DefaultSecurityFilterChain, HttpSecurity> {

        private  Collection<OAuth2ClientAuthenticationProcessingFilter> filters;

        OAuth2ClientAuthenticationConfigurer(
                Collection<OAuth2ClientAuthenticationProcessingFilter> filters) {
            this.filters = filters;
        }

        @Override
        public void configure(HttpSecurity builder)  {
            if(filters!=null&&filters.size()>0){
                for(OAuth2ClientAuthenticationProcessingFilter ssoFilter:filters){
                    ssoFilter.setSessionAuthenticationStrategy(
                            builder.getSharedObject(SessionAuthenticationStrategy.class));
                    builder.addFilterAfter(ssoFilter,
                            AbstractPreAuthenticatedProcessingFilter.class);
                }
            }

        }

    }
}
