package com.example.clienta.securityconfigurer;

import com.zzxdefault.oauth2.sso.config.EnableOAuth2SsoCuntom;
import com.zzxdefault.security.access.DefaultAccessDecisionManager;
import com.zzxdefault.security.config.UserAuthorizationConfig;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;

@Configuration
@ConditionalOnProperty( name = "app.sso",havingValue = "true")
@EnableOAuth2SsoCuntom
public class DefaultSsoWebSecurityConfigurer extends DefaultWebSecurityConfigurer {
    @Override
    protected void configure(HttpSecurity http) throws Exception {

        http.antMatcher("/loginSso")
                .authorizeRequests()
                .antMatchers("/loginSso")
                .permitAll()
                .anyRequest()
                .authenticated();

    }


}
