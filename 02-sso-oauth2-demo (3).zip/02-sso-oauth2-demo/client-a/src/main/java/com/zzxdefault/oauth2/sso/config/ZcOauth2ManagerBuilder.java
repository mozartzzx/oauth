package com.zzxdefault.oauth2.sso.config;

import com.zzxdefault.oauth2.sso.property.ClientResourceProperty;
import com.zzxdefault.oauth2.sso.rest.RemoteRest;
import org.springframework.boot.autoconfigure.security.oauth2.resource.AuthoritiesExtractor;
import org.springframework.boot.autoconfigure.security.oauth2.resource.PrincipalExtractor;
import org.springframework.boot.autoconfigure.security.oauth2.resource.UserInfoTokenServices;
import org.springframework.context.ApplicationContext;
import org.springframework.security.oauth2.client.DefaultOAuth2ClientContext;
import org.springframework.security.oauth2.client.OAuth2ClientContext;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.filter.OAuth2ClientAuthenticationProcessingFilter;
import org.springframework.security.oauth2.client.token.AccessTokenRequest;
import org.springframework.security.oauth2.provider.token.ResourceServerTokenServices;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import java.util.*;


public class ZcOauth2ManagerBuilder {

    private String[] prepertiesprefix;

    private ApplicationContext applicationContext;



    private ClientResourceProperty clientResourceProperty;

    private Map<String, ResourceServerTokenServices> resourceServerTokenServices =new HashMap<String, ResourceServerTokenServices>();

    private Map<String, OAuth2ClientAuthenticationProcessingFilter> filters = new HashMap<String, OAuth2ClientAuthenticationProcessingFilter>();




    public String[] getPrepertiesprefix() {
        return prepertiesprefix;
    }

    public void setPrepertiesprefix(String[] prepertiesprefix) {
        this.prepertiesprefix = prepertiesprefix;
    }




    public ApplicationContext getApplicationContext() {
        return applicationContext;
    }

    public void setApplicationContext(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }
    public ZcOauth2ManagerBuilder setAuthenticationSuccessHandler(AuthenticationSuccessHandler successHandler){
        Collection<OAuth2ClientAuthenticationProcessingFilter> values = this.filters.values();
        for(OAuth2ClientAuthenticationProcessingFilter filter:values){
            filter.setAuthenticationSuccessHandler(successHandler);
        }
        return  this;
    }
    public ZcOauth2ManagerBuilder setAuthenticationSuccessHandler(String key,AuthenticationSuccessHandler successHandler){
        OAuth2ClientAuthenticationProcessingFilter filter = this.getFilter(key);
        filter.setAuthenticationSuccessHandler(successHandler);
        return  this;
    }
    public ZcOauth2ManagerBuilder setAuthenticationFailureHandler(AuthenticationFailureHandler failureHandler){
        Collection<OAuth2ClientAuthenticationProcessingFilter> values = this.filters.values();
        for(OAuth2ClientAuthenticationProcessingFilter filter:values){
            filter.setAuthenticationFailureHandler(failureHandler);
        }
        return  this;
    }
    public ZcOauth2ManagerBuilder setAuthenticationFailureHandler(String key,AuthenticationFailureHandler failureHandler){
        OAuth2ClientAuthenticationProcessingFilter filter = this.getFilter(key);
        if(filter!=null){
            filter.setAuthenticationFailureHandler(failureHandler);
        }
        return  this;
    }


    public ZcOauth2ManagerBuilder failureForwardUrl(String forwardUrl){
        Collection<OAuth2ClientAuthenticationProcessingFilter> values = this.filters.values();
        for(OAuth2ClientAuthenticationProcessingFilter filter:values){
            SimpleUrlAuthenticationFailureHandler simpleUrlAuthenticationFailureHandler = new SimpleUrlAuthenticationFailureHandler(forwardUrl);
            filter.setAuthenticationFailureHandler(simpleUrlAuthenticationFailureHandler);
        }
        return  this;
    }
    public ZcOauth2ManagerBuilder failureForwardUrl(String key,String forwardUrl){
        OAuth2ClientAuthenticationProcessingFilter filter = this.getFilter(key);
        if(filter!=null){
            SimpleUrlAuthenticationFailureHandler simpleUrlAuthenticationFailureHandler = new SimpleUrlAuthenticationFailureHandler(forwardUrl);
            filter.setAuthenticationFailureHandler(simpleUrlAuthenticationFailureHandler);
        }
        return  this;
    }

    public ZcOauth2ManagerBuilder successForwardUrl(String forwardUrl){
        Collection<OAuth2ClientAuthenticationProcessingFilter> values = this.filters.values();
       for(OAuth2ClientAuthenticationProcessingFilter filter:values){
           SavedRequestAwareAuthenticationSuccessHandler savedRequestAwareAuthenticationSuccessHandler = new SavedRequestAwareAuthenticationSuccessHandler();
           savedRequestAwareAuthenticationSuccessHandler.setAlwaysUseDefaultTargetUrl(true);
           savedRequestAwareAuthenticationSuccessHandler.setDefaultTargetUrl(forwardUrl);
           filter.setAuthenticationSuccessHandler(savedRequestAwareAuthenticationSuccessHandler);
       }
        return  this;
    }
    public ZcOauth2ManagerBuilder successForwardUrl(String key,String forwardUrl){
        OAuth2ClientAuthenticationProcessingFilter filter = this.getFilter(key);
        if(filter!=null){
            SavedRequestAwareAuthenticationSuccessHandler savedRequestAwareAuthenticationSuccessHandler = new SavedRequestAwareAuthenticationSuccessHandler();
            savedRequestAwareAuthenticationSuccessHandler.setAlwaysUseDefaultTargetUrl(true);
            savedRequestAwareAuthenticationSuccessHandler.setDefaultTargetUrl(forwardUrl);
            filter.setAuthenticationSuccessHandler(savedRequestAwareAuthenticationSuccessHandler);
        }

        return  this;
    }

    public ZcOauth2ManagerBuilder setAuthoritiesExtractor(String key, AuthoritiesExtractor authoritiesExtractor){
        ResourceServerTokenServices tokenServices = this.getTokenServices(key);
        if(tokenServices!=null){
            if( tokenServices instanceof UserInfoTokenServices) {
                UserInfoTokenServices UserInfoTokenServices = (UserInfoTokenServices)tokenServices;
                UserInfoTokenServices.setAuthoritiesExtractor(authoritiesExtractor);
            }
        }
        return  this;
    }

    public ZcOauth2ManagerBuilder setPrincipalExtractor(String key, PrincipalExtractor principalExtractor){
        ResourceServerTokenServices tokenServices = this.getTokenServices(key);
        if(tokenServices!=null){
            if( tokenServices instanceof UserInfoTokenServices) {
                UserInfoTokenServices UserInfoTokenServices = (UserInfoTokenServices)tokenServices;
                UserInfoTokenServices.setPrincipalExtractor(principalExtractor);
            }
        }
        return  this;
    }
    public ClientResourceProperty getClientResourceProperty() {
        return clientResourceProperty;
    }

    public void setClientResourceProperty(ClientResourceProperty clientResourceProperty) {
        this.clientResourceProperty = clientResourceProperty;
    }




    public void init(){
        OAuth2ClientContext oAuth2ClientContext =  applicationContext.getBean(OAuth2ClientContext.class);
        Map<String, ClientResourceProperty.ClientResource> servers = clientResourceProperty.getCustom();
        Assert.notEmpty(servers,"yaml config not exits");
        if(servers!=null&&!servers.isEmpty()){
            for(String key:servers.keySet()){

                OAuth2RestTemplate rest = new OAuth2RestTemplate(servers.get(key).getClient(),oAuth2ClientContext);
                RemoteRest.put(key,rest);
                UserInfoTokenServices userInfoTokenServices = new UserInfoTokenServices(servers.get(key).getResource().getUserInfoUri(), servers.get(key).getClient().getClientId());
                userInfoTokenServices.setRestTemplate(rest);
                resourceServerTokenServices.put(key,userInfoTokenServices);
                OAuth2ClientAuthenticationProcessingFilter filter = new OAuth2ClientAuthenticationProcessingFilter(
                        clientResourceProperty.getCustom().get(key).getLoginPath());
                filter.setRestTemplate(rest);
                filter.setTokenServices(userInfoTokenServices);
                filter.setApplicationEventPublisher(this.applicationContext);
                filters.put(key,filter);
            }


        }
    }

    public ResourceServerTokenServices getTokenServices(String key){
        return resourceServerTokenServices.get(key);
    }
    public OAuth2ClientAuthenticationProcessingFilter getFilter(String key){
        return filters.get(key);
    }

    public Collection<OAuth2ClientAuthenticationProcessingFilter> buildMachtedFiters(){
        if(prepertiesprefix==null||prepertiesprefix.length==0||(prepertiesprefix.length==1&& StringUtils.isEmpty(prepertiesprefix[0]))){
            return  filters.values();
        }else{
            List<OAuth2ClientAuthenticationProcessingFilter> list = new ArrayList<OAuth2ClientAuthenticationProcessingFilter>();
            for(String key:prepertiesprefix){
                if(filters.containsKey(key)){
                    list.add(filters.get(key));
                }
            }
            Assert.notEmpty(list,"EnableOAuth2SsoCuntom values not match yaml config");
            return list;
        }
    }

}
