package com.zzxdefault.security.service;

import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.core.userdetails.User;

import java.util.Collection;
import java.util.concurrent.ConcurrentHashMap;

public interface UserAuthorizationService {
    ConcurrentHashMap<String, String> loadSecurityMetadataSource();

    Collection<ConfigAttribute> createCustomSecurityMetadata(String url);

    boolean decide(User user, Collection<ConfigAttribute> configAttributes);
}
