package com.zzxdefault.security.uitl;

import org.springframework.security.crypto.codec.Utf8;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;


public class EncryptUtil {

    /**
     * 本方法用于对传入的明文进行MD5加密
     *
     * @param string 需要加密的明文
     * @return 加密后的密文
     * @throws NoSuchAlgorithmException
     * @throws UnsupportedEncodingException
     */
    public static String encryptByMD5(String string) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        MessageDigest messageDigest = MessageDigest.getInstance("md5");
        messageDigest.update(string.getBytes("UTF-8"));
        return new BigInteger(1, messageDigest.digest()).toString(16);
    }

    public static String encryptByBase64(String string) {
        return new String(Base64.getEncoder().encode(string.getBytes()));
    }

    public static String  encrypt(String string) {
        try {
            return  encryptByMD5(encryptByBase64(string));
        } catch (Exception e) {

        }
        return "";
    }
    /**
     * Constant time comparison to prevent against timing attacks.
     * @param expected
     * @param actual
     * @return
     */
    public  static boolean equals(String expected, String actual) {
        byte[] expectedBytes = bytesUtf8(expected);
        byte[] actualBytes = bytesUtf8(actual);
        int expectedLength = expectedBytes == null ? -1 : expectedBytes.length;
        int actualLength = actualBytes == null ? -1 : actualBytes.length;

        int result = expectedLength == actualLength ? 0 : 1;
        for (int i = 0; i < actualLength; i++) {
            byte expectedByte = expectedLength <= 0 ? 0 : expectedBytes[i % expectedLength];
            byte actualByte = actualBytes[i % actualLength];
            result |= expectedByte ^ actualByte;
        }
        return result == 0;
    }

    private static byte[] bytesUtf8(String s) {
        if (s == null) {
            return null;
        }

        return Utf8.encode(s); // need to check if Utf8.encode() runs in constant time (probably not). This may leak length of string.
    }

    public static void main(String[] args) {
       System.out.println(EncryptUtil.encrypt("123456"));
    }

}
