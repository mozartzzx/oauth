package com.zzxdefault.authorizationserver.defaultconfigurer;

import com.zzxdefault.authorizationserver.UserController;
import com.zzxdefault.authorizationserver.client.JdbcClientDetailsServiceConfig;
import com.zzxdefault.authorizationserver.tokenstore.TokenStoreConfiguration;
import com.zzxdefault.authorizationserver.tokenstore.TokenStoreManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.client.JdbcClientDetailsService;
import org.springframework.security.oauth2.provider.token.TokenStore;

/**
 * 授权服务器配置
 * @author zfh
 * @version 1.0
 * @since 2019/6/14 8:50
 */
@Configuration
@EnableAuthorizationServer
@Import({TokenStoreConfiguration.class, JdbcClientDetailsServiceConfig.class})
public class ZcAuthServerConfig extends AuthorizationServerConfigurerAdapter {
    @Autowired(required = false)
    private TokenStore tokenStore;
    @Autowired(required = false)
    private TokenStoreManager tokenStoreManager;
    @Autowired(required = false)
    private JdbcClientDetailsService jdbcClientDetailsService;
    @Override
    public void configure(final AuthorizationServerSecurityConfigurer oauthServer) throws Exception {
        oauthServer.tokenKeyAccess("permitAll()")
                .checkTokenAccess("isAuthenticated()");
        /**
         允许表单验证，浏览器直接发送post请求即可获取tocken
         */
        /**
         * 在使用postman测试authorization_code模式的时候获取token的时候
         * 如果不设置allowFormAuthenticationForClients，会提示未认证的错误(也就是需要)
         * 同理
         * 使用客户端密码模式获取token的话，这个也要开起来
         *
         *
         * @Override
         * public void configure(HttpSecurity http) throws Exception {
         *
         * 		// ensure this is initialized
         * 		frameworkEndpointHandlerMapping();
         * 		if (allowFormAuthenticationForClients) {
         * 			clientCredentialsTokenEndpointFilter(http);
         *        }
         *
         * 		for (Filter filter : tokenEndpointAuthenticationFilters) {
         * 			http.addFilterBefore(filter, BasicAuthenticationFilter.class);
         *        }
         *
         * 		http.exceptionHandling().accessDeniedHandler(accessDeniedHandler);
         *    }
         *
         * private ClientCredentialsTokenEndpointFilter clientCredentialsTokenEndpointFilter(HttpSecurity http) {
         * 		ClientCredentialsTokenEndpointFilter clientCredentialsTokenEndpointFilter = new ClientCredentialsTokenEndpointFilter(
         * 				frameworkEndpointHandlerMapping().getServletPath("/oauth/token"));
         * 		clientCredentialsTokenEndpointFilter
         * 				.setAuthenticationManager(http.getSharedObject(AuthenticationManager.class));
         * 		OAuth2AuthenticationEntryPoint authenticationEntryPoint = new OAuth2AuthenticationEntryPoint();
         * 		authenticationEntryPoint.setTypeName("Form");
         * 		authenticationEntryPoint.setRealmName(realm);
         * 		clientCredentialsTokenEndpointFilter.setAuthenticationEntryPoint(authenticationEntryPoint);
         * 		clientCredentialsTokenEndpointFilter = postProcess(clientCredentialsTokenEndpointFilter);
         * 		http.addFilterBefore(clientCredentialsTokenEndpointFilter, BasicAuthenticationFilter.class);
         * 		return clientCredentialsTokenEndpointFilter;
         * }
         * 原理其实是在构建的时候加进去一个过滤器,判断客户端ID和密码是否输入正确
         * 如果客户端端ID和密码正确就是认证通过
         *
         */
        oauthServer.allowFormAuthenticationForClients();
    }

    @Override
    public void configure(final ClientDetailsServiceConfigurer clients) throws Exception {
        if(jdbcClientDetailsService!=null){
            clients.withClientDetails(jdbcClientDetailsService);
        }else{
           /* clients.inMemory()
                    .withClient("SampleClientId")
                    .secret( passwordEncoder.encode("secret") )
                    .authorizedGrantTypes("authorization_code", "client_credentials", "refresh_token")
                    .scopes("all")
                    .autoApprove(true)
                    .redirectUris("http://localhost:8301/login","http://localhost:8301/loginqq","http://localhost:8301/loginweixin","http://localhost:8302/login")
                    .and()
                    .withClient("test")
                    .secret(  passwordEncoder.encode("123456") )
                    .authorizedGrantTypes("authorization_code", "client_credentials", "refresh_token")
                    .scopes("all")
                    .autoApprove(true)
                    .redirectUris("http://www.baidu.com");*/
        }
    }

    // 必须进行redirectUris的配置，否则请求授权码时会报错：error="invalid_request", error_description="At least one redirect_uri must be registered with the client."

    @Override
    public void configure(AuthorizationServerEndpointsConfigurer endpoints) throws Exception {
        //super.configure(endpoints);
        if(tokenStore !=null){
            /**
             * 将tokenStore换成redisTokenStore
             */
            endpoints.tokenStore(tokenStore);
        }
        if(tokenStoreManager!=null){
            endpoints.accessTokenConverter(tokenStoreManager.getAccessTokenConverter());
        }

    }
}
