package com.zzxdefault.defalutconfigurer;

import com.zzxdefault.oauth2.sso.config.EnableOAuth2SsoCuntom;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConditionalOnProperty( name = "app.sso",havingValue = "true")
@EnableOAuth2SsoCuntom
public class DefaultSsoWebSecurityConfigurer extends DefaultWebSecurityConfigurer {


}
