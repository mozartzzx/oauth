package com.zzxdefault.authorizationserver.tokenstore;

import org.springframework.security.oauth2.provider.token.AccessTokenConverter;
import org.springframework.security.oauth2.provider.token.store.redis.RedisTokenStore;

public abstract class TokenStoreManager {
    /**
     * 适用于 redisTokenStore 的 其他配置
     * @param redisTokenStore
     */
    public abstract void configer(RedisTokenStore redisTokenStore);

    /**
     * 适用于 jwt 的配置
     * @return
     */
    public abstract AccessTokenConverter getAccessTokenConverter();
}
