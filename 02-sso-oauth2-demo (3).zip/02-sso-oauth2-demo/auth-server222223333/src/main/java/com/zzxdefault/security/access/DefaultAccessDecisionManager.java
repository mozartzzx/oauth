package com.zzxdefault.security.access;

import com.zzxdefault.security.service.UserAuthorizationService;
import org.springframework.security.access.AccessDecisionManager;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.oauth2.provider.OAuth2Authentication;

import java.util.Collection;


public class DefaultAccessDecisionManager implements AccessDecisionManager {

    private UserAuthorizationService userAuthorizationService;
    public DefaultAccessDecisionManager(UserAuthorizationService userAuthorizationService){
        this.userAuthorizationService=userAuthorizationService;
    }
    @Override
    public void decide(Authentication authentication, Object o, Collection<ConfigAttribute> configAttributes) throws AccessDeniedException, InsufficientAuthenticationException {
        if(null== configAttributes || configAttributes.size() <=0) {
            throw new AccessDeniedException("no perm");
        }

        User user =(User)authentication.getPrincipal();
        if(userAuthorizationService!=null){
           boolean access =  userAuthorizationService.decide(user,configAttributes);
           if(access){
               return;
           }
        }


        Collection<? extends GrantedAuthority> grantedAuthoritys = null;
        if(authentication instanceof OAuth2Authentication){
            Object userobject=((OAuth2Authentication) authentication).getUserAuthentication().getPrincipal();
            grantedAuthoritys = ((User)userobject).getAuthorities();
        }else{
            grantedAuthoritys = authentication.getAuthorities();
        }
        if(grantedAuthoritys ==null){

            throw new AccessDeniedException("no perm");
        }
        for(ConfigAttribute configAttribute: configAttributes){
            for(GrantedAuthority grantedAuthority:grantedAuthoritys){
                if(configAttribute.getAttribute().equalsIgnoreCase(grantedAuthority.getAuthority())){
                    return;
                }
            }
        }

        throw new AccessDeniedException("no perm");


    }

    @Override
    public boolean supports(ConfigAttribute configAttribute) {
        return true;
    }

    @Override
    public boolean supports(Class<?> aClass) {
        return true;
    }
}
