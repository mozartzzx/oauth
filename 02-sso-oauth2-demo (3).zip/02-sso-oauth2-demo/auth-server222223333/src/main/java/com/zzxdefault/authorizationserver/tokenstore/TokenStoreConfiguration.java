package com.zzxdefault.authorizationserver.tokenstore;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.security.oauth2.provider.token.TokenStore;

/**
 * RedisTokenStoreConfig
 * @author zzx
 * @date 2019/10/14
 */
@Configuration
public class TokenStoreConfiguration {

	private static final String TOKENSOTRE_TYPE_JWT="jwt";
	private static final String TOKENSOTRE_TYPE_REDIS="redis";
	private static final String TOKENSOTRE_TYPE_INMEMORY="inmemory";

	@Value("app.tokenStoreType:redis")
	private String tokenStoreType;

	@Autowired(required = false)
	private RedisConnectionFactory redisConnectionFactory;
	@Autowired(required = false)
	private TokenStoreManager tokenStoreManager;

	private TokenStoreConfigurer tokenStoreConfigurer = new TokenStoreConfigurer();

    /**
	 * tokenGranter -- AuthorizationServerTokenServices -- tokenStore
     * TokenStore的作用
     * @return
     */
	@Bean
	public TokenStore tokenStore (){
		tokenStoreConfigurer.setTokenStoreManager(tokenStoreManager);
		tokenStoreConfigurer.setRedisConnectionFactory(redisConnectionFactory);
		tokenStoreConfigurer.setTokenStoreType(tokenStoreType);
		return  tokenStoreConfigurer.tokenStore();
	}
}