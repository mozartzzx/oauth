package com.zzxdefault.oauth2.sso.rest;

import org.springframework.security.oauth2.client.OAuth2RestTemplate;

import java.util.HashMap;
import java.util.Map;

public class RemoteRest {
    public static Map<String, OAuth2RestTemplate> restTemplateMap = new HashMap<String, OAuth2RestTemplate>();

    public static  OAuth2RestTemplate get(String key) {
        return restTemplateMap.get(key);
    }

    public static void put(String key, OAuth2RestTemplate  restTemplate) {
        RemoteRest.restTemplateMap.put(key,restTemplate);
    }
}
