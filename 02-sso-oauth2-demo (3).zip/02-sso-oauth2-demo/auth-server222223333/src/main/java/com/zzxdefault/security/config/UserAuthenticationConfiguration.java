package com.zzxdefault.security.config;

import com.zzxdefault.security.service.UserRelationService;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 *
 * 从@EnableWebSecurity中的
 * @EnableGlobalAuthentication可以看出
 * 加入了一个AuthenticationConfiguration的配置类
 *
 *
 * WebSecurityConfigurerAdapter中有一段
 * @Autowired
 *        public void setAuthenticationConfiguration(
 * 			AuthenticationConfiguration authenticationConfiguration) {
 * 		this.authenticationConfiguration = authenticationConfiguration;
 *    }
 * 注入了  AuthenticationConfiguration
 * 并通过 其 init(..) -- getHttp() --- authenticationManager() --
 * 找到
 * authenticationManager = authenticationConfiguration
 * 						.getAuthenticationManager();
 * 这个	authenticationManager 会被设置到
 * authenticationBuilder.parentAuthenticationManager(authenticationManager);
 *
 *
 * 通过authenticationConfiguration的.getAuthenticationManager() 获取到 authenticationManager
 * 这个过程很复杂
 *
 * 通过
 *
 *  @Autowired(required = false)
 * 	public void setGlobalAuthenticationConfigurers(
 * 			List<GlobalAuthenticationConfigurerAdapter> configurers) throws Exception {
 * 		Collections.sort(configurers, AnnotationAwareOrderComparator.INSTANCE);
 * 		this.globalAuthConfigurers = configurers;
 *  }
 *  获取到全局的GlobalAuthenticationConfigurerAdapter配置
 *
 *  其中有一个实现类InitializeUserDetailsBeanManagerConfigurer
 *
 *
 *  里面有
 *
 *  @Override    * 	public void init(AuthenticationManagerBuilder auth) throws Exception {
 * 		auth.apply(new InitializeUserDetailsManagerConfigurer());    * 	}
 *
 * 	class InitializeUserDetailsManagerConfigurer
 * 			extends GlobalAuthenticationConfigurerAdapter {
 *        @Override
 *        public void configure(AuthenticationManagerBuilder auth) throws Exception {
 * 			if (auth.isConfigured()) {
 * 				return;
 *            }
 * 			UserDetailsService userDetailsService = getBeanOrNull(
 * 					UserDetailsService.class);
 * 			if (userDetailsService == null) {
 * 				return;
 *            }
 *
 * 			PasswordEncoder passwordEncoder = getBeanOrNull(PasswordEncoder.class);
 * 			UserDetailsPasswordService passwordManager = getBeanOrNull(UserDetailsPasswordService.class);
 *
 * 			DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
 * 			provider.setUserDetailsService(userDetailsService);
 * 			if (passwordEncoder != null) {
 * 				provider.setPasswordEncoder(passwordEncoder);
 *            }
 * 			if (passwordManager != null) {
 * 				provider.setUserDetailsPasswordService(passwordManager);
 *            }
 * 			provider.afterPropertiesSet();
 *
 * 			auth.authenticationProvider(provider);
 *        }
 *
 *
 *
 * 可以看出主要是对AuthenticationManagerBuilder
 * 通过auth.authenticationProvider(provider);
 * 加入DaoAuthenticationProvider
 *
 * 通用我们也可以自己在自定义的WebSecurityConfigurerAdapter的
 *    @Override
 *     protected void configure(AuthenticationManagerBuilder auth) throws Exception {
 *         super.configure(auth);
 *         //添加自定义的认证管理类
 *         auth.authenticationProvider(provider);
 *
 *     }
 * 加入自己的认证提供
 * ProviderManager会按照添加入认证请求链中的顺序来验证
 * 这样就可以用一个认证处理器链来支持应用的多种AuthenticationProvider认证模式
 *
 * 我们先看默认的DaoAuthenticationProvider及其父类AbstractUserDetailsAuthenticationProvider
 * 其中就使用到了模板模式
 *
 * try {
 *          //前置校验 比如用户是否锁定，是否禁用，是否过期
 * 			preAuthenticationChecks.check(user);
 * 			additionalAuthenticationChecks(user,
 * 					(UsernamePasswordAuthenticationToken) authentication);
 *                }
 * 		catch (AuthenticationException exception) {
 * 			if (cacheWasUsed) {
 * 				// There was a problem, so try again after checking
 * 				// we're using latest data (i.e. not from the cache)
 * 				cacheWasUsed = false;
 * 				user = retrieveUser(username,
 * 						(UsernamePasswordAuthenticationToken) authentication);
 * 				preAuthenticationChecks.check(user);
 * 				additionalAuthenticationChecks(user,
 * 						(UsernamePasswordAuthenticationToken) authentication);
 *            }
 * 			else {
 * 				throw exception;
 *            }
 *        }
 *      //后置校验 比如 密码是否过期
 * 		postAuthenticationChecks.check(user);
 *
 *
 * --AbstractUserDetailsAuthenticationProvider  authenticate
 *      -- retrieveUser
 *              --DaoAuthenticationProvider  retrieveUser
 *                  --UserDetails loadedUser = this.getUserDetailsService().loadUserByUsername(username);
 *      --AbstractUserDetailsAuthenticationProvider additionalAuthenticationChecks
 *              --DaoAuthenticationProvider --additionalAuthenticationChecks
 *                  --passwordEncoder.matches(presentedPassword, userDetails.getPassword())
 *
 * 可以看出使用到了 UserDetailsService 和 PasswordEncoder
 * 所以可以自定义自己的 UserDetailsService获取用户和PasswordEncoder检验密码
 * 默认的PasswordEncoder是DelegatingPasswordEncoder，可以看出是委派模式 至于功能自己看吧
 *
 */
@Configuration
@ConditionalOnBean(UserRelationService.class)
public class UserAuthenticationConfiguration {

    @Bean("userDetailsService")
    public UserDetailsService getUserDetailsService(ObjectProvider<UserRelationService> userRelationServiceProvider){
        UserRelationService userRelationService = userRelationServiceProvider.getIfAvailable();
        if(userRelationService==null){
            return null;
        }
        return new DefaultDaoUserDetailService(userRelationService);
    }

    @Bean("passwordEncoder")
    public PasswordEncoder getPasswordEncoder(ObjectProvider<UserRelationService> userRelationServiceProvider){
        UserRelationService userRelationService = userRelationServiceProvider.getIfAvailable();
        if(userRelationService==null){
            return null;
        }
        return new DefaultPasswordEncoder(userRelationService);
    }


    class DefaultDaoUserDetailService implements UserDetailsService {

        private UserRelationService userRelationService;

        public DefaultDaoUserDetailService(UserRelationService userRelationService){
            this.userRelationService=userRelationService;
        }

        //通过用户名 获取用户数据
        //正常是从数据库获取，测试就写写死好了
        @Override
        public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
            UserDetails userDetails =userRelationService.loadUserByUsername(username);
            return userDetails;
        }
    }

    class DefaultPasswordEncoder implements PasswordEncoder{
        private UserRelationService userRelationService;
        public DefaultPasswordEncoder(UserRelationService userRelationService){
            this.userRelationService=userRelationService;
        }

        @Override
        public String encode(CharSequence charSequence) {
            return  userRelationService.encrypt(charSequence.toString());
        }
        //rawPassword 需要加密后密码。也就是等于用户输入的
        //encodedPassword 要验证的密码，也就是用户存数据库里的密码
        @Override
        public boolean matches(CharSequence rawPassword, String encodedPassword) {
            String rawPasswordEncoded = encode(rawPassword);
            return userRelationService.matchePassword(encodedPassword, rawPasswordEncoded);
        }
    }

}


