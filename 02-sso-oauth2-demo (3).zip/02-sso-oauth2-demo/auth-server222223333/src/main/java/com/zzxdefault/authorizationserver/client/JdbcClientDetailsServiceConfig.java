package com.zzxdefault.authorizationserver.client;

import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.provider.client.JdbcClientDetailsService;

import javax.sql.DataSource;

@Configuration
public class JdbcClientDetailsServiceConfig {

    @Bean
    public JdbcClientDetailsService getJdbcClientDetailsService(DataSource dataSource){
        return  new JdbcClientDetailsService(dataSource);
    }
}
