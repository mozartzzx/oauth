package com.example.authserver.dao;

import com.example.authserver.entity.ext.ClientEntityExt;
import com.example.authserver.tkmybatis.GenericDao;

import java.util.List;

public interface ClientDao extends GenericDao<ClientEntityExt> {

    List<ClientEntityExt> selectlist();

    void updatebyclientid(ClientEntityExt clientEntityExt);

    void updateinfobyclientid(ClientEntityExt clientEntityExt);

    int deletein(ClientEntityExt clientEntityExt);

    void deleteinfoin(ClientEntityExt clientEntityExt);

}
