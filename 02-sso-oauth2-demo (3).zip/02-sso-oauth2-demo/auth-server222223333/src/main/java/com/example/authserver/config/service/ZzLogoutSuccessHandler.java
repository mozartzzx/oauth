package com.example.authserver.config.service;


import com.alibaba.fastjson.JSON;
import com.example.authserver.result.module.I18nEnums;
import com.example.authserver.result.module.JsonResult;
import com.example.authserver.result.module.JsonResultMessage;
import com.example.authserver.result.module.JsonResultStateEnums;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
public class ZzLogoutSuccessHandler implements LogoutSuccessHandler {
    public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
        JsonResultMessage jsonResultMessage = new JsonResultMessage(I18nEnums.success);
        JsonResult<?> jsonResult = new JsonResult(JsonResultStateEnums.SUCCESS, jsonResultMessage);
        response.getOutputStream().write(JSON.toJSONString(jsonResult).getBytes("utf-8"));
        response.getOutputStream().flush();
        response.getOutputStream().close();
        return;
    }
}

