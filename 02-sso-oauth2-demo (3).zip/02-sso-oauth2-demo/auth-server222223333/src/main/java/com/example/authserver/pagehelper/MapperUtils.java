package com.example.authserver.pagehelper;

import com.example.authserver.result.module.I18nEnums;
import com.example.authserver.result.module.JsonResultUtils;
import org.apache.commons.lang3.StringUtils;
import tk.mybatis.mapper.entity.EntityColumn;
import tk.mybatis.mapper.entity.Example.Criteria;
import tk.mybatis.mapper.mapperhelper.EntityHelper;

import java.util.Calendar;
import java.util.Date;

public class MapperUtils {

	
	/**
	 * 
	* 将前台的排序字段转换成数据库类型
	*
	* @param fileding
	* @param clasz
	* @return
	* 
	* @author xulb
	* @version V1.0
	* 
	* @since 2018年1月21日 下午3:56:41
	 */
    static public String FieldToColnum(String fileding, Class<?> clasz) {
        //ts desc
    	if(fileding==null)
    	{
    		return null;
    	}
        String result = "";
        String[] fildes = fileding.split(",");

        if(StringUtils.isBlank(fileding))
        {
        	return "d_date desc";
        }
        for (String string : fildes) {
            boolean first = true;
            String[] cols = string.split(" ");
            String col = "";
            String sort = "asc";
            for (String tempString : cols) {
             
                if (StringUtils.isNotBlank(tempString)) {

                    if (first) {
                        EntityColumn protities = EntityHelper.getEntityTable(clasz).getPropertyMap().get(tempString);
                        if (protities == null) {
                            JsonResultUtils.throwServiceException(I18nEnums.msg_error_no_order_field, tempString);
                        } else {
                            col = protities.getColumn();
                        }
                        first = false;
                    } else {
                        sort = tempString;
                    }

                }
            }
            if (StringUtils.isNotBlank(col)) {
                result += col + " " + sort + ",";
            }


        }
        if (result.contains(",")) {
            result = result.substring(0, result.length() - 1);
        }
        return result;
    }

    /**
     * 
    * 防止自定义排序出现sql注入
    *
    * @param fileding
    * @param clasz
    * 
    * @author xulb
    * @version V1.0
    * 
    * @since 2018年3月13日 下午3:33:03
     */
    static public void checkInjection(String fileding, Class<?> clasz )
    {

        //ts desc
    	if(StringUtils.isBlank(fileding))
    	{
    		return ;
    	}
        String[] fildes = fileding.split(",");
        for (String string : fildes) {
            String[] cols = string.split(" ");
            String tempString=cols[0];
            if(cols[1].equals("asc")||cols[1].equals("desc"))
            {
            	
            }
            else
            {
            	 JsonResultUtils.throwServiceException();
            }
            if(cols.length!=2)
            {
            	   JsonResultUtils.throwServiceException(I18nEnums.msg_error_no_order_field, tempString);
            }
            EntityColumn protities = EntityHelper.getEntityTable(clasz).getPropertyMap().get(tempString);
            if (protities == null) {
                JsonResultUtils.throwServiceException(I18nEnums.msg_error_no_order_field, tempString);
            } else {
            }
    
        }
    }
    static public void andLike(String prop, String row, Criteria criteria) {
        if (StringUtils.isNotBlank(row)) {
            criteria.andLike(prop, "%" + row + "%");
        }

    }
    
    
     
    /**
     * 
    * 封装了时间查询的工具类
    *
    * @param prop 对象
    * @param star 起始时间
    * @param end  结束时间
    * @param criteria
    * 
    * @author xulb
    * @version V1.0
    * 
    * @since 2018年1月23日 上午9:14:11
     */
    static public void andBetween(String prop, Date star,Date end ,Criteria criteria) {
    	
    	if(star==null&&end==null)
    	{
    		return ;
    	}
    	if(star==null)
    	{
    		star=new Date(0);
    	}
    	if(end==null)
    	{
    		 Date today = new Date();
    		 Calendar c = Calendar.getInstance();
    		 c.setTime(today);
    		 c.add(Calendar.DAY_OF_MONTH, 1);// 今天+1天
    		 Date tomorrow = c.getTime();
    		 end=tomorrow;
    	}
    	else {
    		Calendar calendar = Calendar.getInstance();
    		calendar.setTime(end);
    		calendar.add(Calendar.DAY_OF_MONTH, 1);
    		end= calendar.getTime();
    	}
            criteria.andBetween(prop,star,end);

}

    
    
    /**
     * 
    * 封装了时间查询的工具类，时间查询不加一天
    *
    * @param prop 对象
    * @param star 起始时间
    * @param end  结束时间
    * @param criteria
    * 
    * @author zhbin
    * @version V1.0
    * 
    * @since 2018年1月23日 上午9:14:11
     */
    static public void andBetweenNotAddDay(String prop, Date star,Date end ,Criteria criteria) {
    	
    	if(star==null&&end==null)
    	{
    		return ;
    	}
    	if(star==null)
    	{
    		star=new Date(0);
    	}
    	if(end==null)
    	{
    		 Date today = new Date();
    		 Calendar c = Calendar.getInstance();
    		 c.setTime(today);
    		 Date tomorrow = c.getTime();
    		 end=tomorrow;
    	}
    	else {
    		Calendar calendar = Calendar.getInstance();
    		calendar.setTime(end);
    		end= calendar.getTime();
    	}
            criteria.andBetween(prop,star,end);

}
    
    

}
