package com.example.authserver.exception;

import com.example.authserver.result.module.I18nEnums;
import com.example.authserver.result.module.JsonResultMessage;


/**
 * 
 * 系统公共的应用级别的错误，引入国际化的枚举类作为参数变量
 */
public class ServiceException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JsonResultMessage jsonResultMessage;
	public ServiceException(Throwable e) {
		this.jsonResultMessage = new JsonResultMessage(I18nEnums.default_serviceexception_error);
	}
	/**
	 * 
	 * 
	 */
	public ServiceException() {
		this.jsonResultMessage = new JsonResultMessage(I18nEnums.default_serviceexception_error);
	}
	public ServiceException(I18nEnums i18nMessage,Object... r) {
		this.jsonResultMessage = new JsonResultMessage(i18nMessage, r);
	}
	public ServiceException(JsonResultMessage i18nMessage) {
		this.jsonResultMessage = i18nMessage;
	}
	public JsonResultMessage getJsonResultMessage() {
		return jsonResultMessage;
	}
	
	public JsonResultMessage getJsonResultMessage(JsonResultMessage jsonResultMessage) {
		return jsonResultMessage;
	}
	/**
	*
	* 
	* @return
	* @see Throwable#getMessage()
	* 
	*/
	@Override
	public String getMessage() {
		String message = super.getMessage();
		return getJsonResultMessage().toString()+(message==null?"":("\n"+message));
	}
	

}
