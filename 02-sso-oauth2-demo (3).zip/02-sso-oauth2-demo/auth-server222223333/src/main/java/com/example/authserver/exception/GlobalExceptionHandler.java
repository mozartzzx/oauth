/**
 * Copyright (c) ${year}. www.sunnyintell.com Inc. All rights reserved.
 * 注意：本内容仅限于宁波舜宇智能科技有限公司内部传阅，禁止外泄以及用于其他的商业目的。否则追究其法律责任。
 */
package com.example.authserver.exception;


import com.alibaba.fastjson.JSON;
import com.example.authserver.result.module.*;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.NonTransientDataAccessException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Optional;


/**
 * 
 * 顶级异常捕获，遵循只进一个最匹配的异常处理方法
 *
 */
@ControllerAdvice
public class GlobalExceptionHandler {
	

	
	private static Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);


    @ExceptionHandler({ServiceException.class
    	,DevelopErrorException.class
    	,DataVersionExpiredExcption.class})
    @ResponseBody
    public JsonResult developErrorExceptionHandler(ServiceException exception) throws Exception  
    {
    	errorPrint(exception);
        if(exception instanceof DevelopErrorException){

        }
        return JsonResultUtils.getJsonResultError(exception.getJsonResultMessage());
    }

    /**
     *
     * 根据抛出的异常进行值得补货，按数据库进行分析
     * <br>Mysql：
     * <br>Oracle：
     *
     * @param exception
     * @return
     * @throws Exception
     * @modifyDate: (这里填写最近修改时间)
     *
     */
    @ExceptionHandler({NonTransientDataAccessException.class})
    @ResponseBody
    public JsonResult duplicateKeyExceptionHandler(NonTransientDataAccessException exception) throws Exception
    {
        //
        Optional<UniqueIndex> ou = UniqueIndexKeyUtils.getUniqueKey(exception);
        errorPrint(exception);
        if(ou.isPresent()){
            UniqueIndex ui = ou.get();
            String toReplace;
            if(StringUtils.isBlank(ui.getMod())){
                toReplace = I18nPub.global_msg+ui.getKey();
            }if("without".equalsIgnoreCase(ui.getMod())){
                toReplace=ui.getKey();

                JsonResultMessage jsonResultMessage = new JsonResultMessage(I18nEnums.msg_error_value_repeat,toReplace);
                jsonResultMessage.setPs(toReplace+"不能重复。");
                JsonResult jr = JsonResultUtils.getJsonResultError(jsonResultMessage);
                log.error(JSON.toJSONString(jr));
                return jr;
            }else{
                toReplace = ui.getMod()+"."+ui.getKey();
            }
            JsonResult jr = JsonResultUtils.getJsonResultError(I18nEnums.msg_error_value_repeat,toReplace);
            log.error(JSON.toJSONString(jr));
            return jr;
        }



        return JsonResultUtils.getJsonResultError();
    }
    
    private void errorPrint(Exception e)
    {
		log.error("系统异常{}",e);
	}
}