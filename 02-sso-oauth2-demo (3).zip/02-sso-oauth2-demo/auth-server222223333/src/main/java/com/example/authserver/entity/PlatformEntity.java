package com.example.authserver.entity;

import com.example.authserver.entity.ext.ClientEntityExt;

import java.util.ArrayList;
import java.util.List;

public class PlatformEntity {

    private  String name;
    private List<ClientEntityExt> child;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<ClientEntityExt> getChild() {
        if(child==null){
            child = new ArrayList<ClientEntityExt>();
        }
        return child;
    }

    public void setChild(List<ClientEntityExt> child) {
        this.child = child;
    }
}
