/**
 * Copyright (c) 2018. www.sunnyintell.com Inc. All rights reserved.
 * 注意：本内容仅限于宁波舜宇智能科技有限公司内部传阅，禁止外泄以及用于其他的商业目的。否则追究其法律责任。
 */
package com.example.authserver.result.module;

/**
 * 国际化前缀，配合前端
 */

public class I18nPub {
	/**
	 * 提示消息的前缀
	 */
	public final static String global_msg="global.msg.";
	/**
	 * 全局公用参数的前缀
	 */
	public final static String global_field="global.field.";
	/**
	 * 模块参数的前缀
	 */
	public final static String module="";
	
	
	
	
}
