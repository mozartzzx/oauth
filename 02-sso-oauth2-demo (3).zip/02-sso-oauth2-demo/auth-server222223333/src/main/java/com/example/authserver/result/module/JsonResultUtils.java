package com.example.authserver.result.module;

import com.example.authserver.exception.DevelopErrorException;
import com.example.authserver.exception.ServiceException;

/**
 * 
 * @ClassName:  JsonResultUtils   
 * @Description:封装和返回Json数据
 */
public class JsonResultUtils{
	
	public static void main(String[] args) {
		Object data = new Object();
		JsonResultUtils.getJsonResultSuccess(data);
		//JsonResultUtils.getJsonResultSuccess(I18nEnums.logon_success,I18nEnums.);
		JsonResultUtils.getJsonResultSuccess(data);

	}
	/**
	 * 
	* 创建一条前后端的通信消息
	*
	* @param state 请求结果状态JsonResultStateEnums
	* @param data 操作成功要返回的消息
	*  i18nMessage 消息主体，从I18nEnums中取
	*  toReplace 消息主体的替换变量，类型可为 I18nEnums、String、Integer、BigDecimal
	* @return
	 */
	public static <T> JsonResult<T> getJsonResult(JsonResultStateEnums state,T data,JsonResultMessage message){
		return new JsonResult<T>(state,data, message);
	}
	/**
	 * 
	* 创建一条前后端的通信消息
	*
	* @param state 请求结果状态JsonResultStateEnums
	* @param i18nMessage 消息主体，从I18nEnums中取
	* @param toReplace 消息主体的替换变量，类型可为 I18nEnums、String、Integer、BigDecimal
	* @return
	 */
	public static <T> JsonResult<T> getJsonResult(JsonResultStateEnums state,I18nEnums i18nMessage,Object... toReplace){
		return new JsonResult<T>(state, i18nMessage,toReplace);
	}
	/**
	 * 
	* 创建一条前后端的通信消息
	*
	* @param state 请求结果状态JsonResultStateEnums
	* @param i18nMessage 消息主体，从I18nEnums中取
	* @return
	 */
	public static <T> JsonResult<T> getJsonResult(JsonResultStateEnums state,I18nEnums i18nMessage){
		return new JsonResult<T>(state, i18nMessage);
	}

	public static <T> JsonResult<T> getJsonResult(JsonResultStateEnums state,T data){
		return new JsonResult<T>(state,data);
	}
	/**
	 * 
	* 创建一条前后端的通信失败的消息
	*
	* @param i18nMessage 消息主体，从I18nEnums中取
	* @param toReplace 消息主体的替换变量，类型可为 I18nEnums、String、Integer、BigDecimal
	* @return JsonResult<T>
	 */
	public static <T> JsonResult<T> getJsonResultError(I18nEnums i18nMessage,Object... toReplace){
		return new JsonResult<T>(JsonResultStateEnums.ERROR, i18nMessage,toReplace);
	}
	public static <T> JsonResult<T> getJsonResultError(){
		return new JsonResult<T>(JsonResultStateEnums.ERROR, I18nEnums.error);
	}
	/**
	 * 
	* 创建一条前后端的通信失败的消息
	*
	* @param message 多语言的对象JsonResultMessage
	* @return
	 */
	public static <T> JsonResult<T> getJsonResultError(JsonResultMessage message){
		return new JsonResult<T>(JsonResultStateEnums.ERROR,message);
	}
	/**
	 * 
	* 创建一条前后端的通信成功的消息
	*
	* @param data
	* @param message
	* @return
	*
	 */
	public static <T> JsonResult<T> getJsonResultSuccess(T data,JsonResultMessage message){
		return new JsonResult<T>(JsonResultStateEnums.SUCCESS,data,message);
	}
	/**
	 * 
	* 创建一条前后端的通信成功的消息
	*
	* @param message  消息体，通过new JsonResultMessage  来进行传值
	* @return
	 */
	public static <T> JsonResult<T> getJsonResultSuccess(JsonResultMessage message){
		return new JsonResult<T>(JsonResultStateEnums.SUCCESS,message);
	}

	
	public static <T> JsonResult<T> getJsonResultSuccess(I18nEnums i18nMessage){
		return new JsonResult<T>(JsonResultStateEnums.SUCCESS, i18nMessage);
	}
	public static <T> JsonResult<T> getJsonResultSuccess(){
		return new JsonResult<T>(JsonResultStateEnums.SUCCESS, I18nEnums.success);
	}
	
	

	/**
	* 返回多占位符替换提示
	* 
	* @param i18nEnums
	* @param toReplace
	* @return
	* 
	*/
	public static <T> JsonResult<T> getJsonResultSuccessMoreReplace(I18nEnums i18nEnums,Object...toReplace){
		return JsonResultUtils.getJsonResultSuccess(
				new JsonResultMessage(i18nEnums,toReplace));
	}
	/**
	 * 
	* 创建一条前后端的通信成功的消息
	*
	* @param data 操作成功要返回的消息
	* @return JsonResult<T>
	*
	 */
	public static <T> JsonResult<T> getJsonResultSuccess(T data){
		return new JsonResult<T>(JsonResultStateEnums.SUCCESS,data, I18nEnums.success);
	}
	public static <T> JsonResult<T> getJsonRedirectResultSuccess(T data){
		return new JsonResult<T>(JsonResultStateEnums.FOUND,data, I18nEnums.success);
	}
	public static <T> JsonResult<T> getJsonResultSuccess(T data,I18nEnums i18nMessage){
		return new JsonResult<T>(JsonResultStateEnums.SUCCESS,data, i18nMessage);
	}
	
	
	public static <T> boolean isSuccess(JsonResult<T> jsonResult) {
		return JsonResultStateEnums.SUCCESS.getState() == jsonResult.getState();
	}
	public static <T>  boolean isError(JsonResult<T>  jsonResult) {
		return JsonResultStateEnums.ERROR.getState() == jsonResult.getState();
	}
	public static void throwServiceException(){
		throw new ServiceException();
	}
	public static void throwServiceException(I18nEnums i18nMessage,Object... toReplace){
		throw new ServiceException(i18nMessage,toReplace);
	}

	public static void throwDevelopErrorException(){
		throw new DevelopErrorException();
	}
	public static void throwDevelopErrorException(String msg){
		throw new DevelopErrorException(msg);
	}
}
