package com.example.authserver.exception;


import com.example.authserver.result.module.I18nEnums;

public class DataVersionExpiredExcption extends ServiceException {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DataVersionExpiredExcption(){
        super();
    }
	public DataVersionExpiredExcption(I18nEnums i18nMessage){
        super(i18nMessage);
    }
}
