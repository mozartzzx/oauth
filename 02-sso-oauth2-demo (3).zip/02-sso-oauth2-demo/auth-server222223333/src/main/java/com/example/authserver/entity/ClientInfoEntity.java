package com.example.authserver.entity;

import javax.persistence.Column;
import javax.persistence.Table;

@Table(name = "O_CLIENT_INFO")
public class ClientInfoEntity {

    @Column(name = "CLIENT_ID")
    private String clientId;
    @Column(name = "CLIENT_NAME")
    private String clientName;
    @Column(name = "ICON")
    private String icon;
    @Column(name = "COLOR")
    private String color;
    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}
