package com.example.authserver.config.service;

import com.alibaba.fastjson.JSON;
import com.example.authserver.result.module.*;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class ZzAuthenticationFailureHandler implements AuthenticationFailureHandler {


    public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response, AuthenticationException exception) throws IOException, ServletException {

        JsonResultMessage jsonResultMessage = new JsonResultMessage(I18nEnums.login_faild);
        jsonResultMessage.setPs("用户名或密码错误");
        JsonResult<?> jsonResult = new JsonResult(JsonResultStateEnums.ERROR, jsonResultMessage);
        response.getOutputStream().write(JSON.toJSONString(jsonResult).getBytes("utf-8"));
        response.getOutputStream().flush();
        response.getOutputStream().close();
        return;
    }
}