/**
 * Copyright (c) 2018. www.sunnyintell.com Inc. All rights reserved.
 * 注意：本内容仅限于宁波舜宇智能科技有限公司内部传阅，禁止外泄以及用于其他的商业目的。否则追究其法律责任。
 */
package com.example.authserver.exception;

import com.alibaba.fastjson.JSONObject;
import com.example.authserver.result.module.I18nEnums;

/**
 * 开发过程中未规范，抛出的异常
 */
public class DevelopErrorException extends ServiceException {
	
	/**   
	 * 默认构造函数
	 */
	public DevelopErrorException() {
		super(I18nEnums.develop_error);
	}
	/**
	 * 默认构造函数,可传入错误信息，由于是面向开发人员，直接显示中文，不再进行可视化。
	 *
	 */
	public DevelopErrorException(String msg) {
		super(I18nEnums.develop_error,msg);
	}
	/** (非 Javadoc) 
	* <p>Title: getMessage</p> 
	* <p>Description: </p> 
	* @return 
	* @see Throwable#getMessage()
	*/
	@Override
	public String getMessage() {
		
		return JSONObject.toJSONString(getJsonResultMessage());
	}
}
