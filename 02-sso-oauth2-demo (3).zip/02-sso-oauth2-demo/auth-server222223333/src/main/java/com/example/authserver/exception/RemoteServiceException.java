package com.example.authserver.exception;

/**
 * 
 * 系统公共的应用级别的错误，引入国际化的枚举类作为参数变量
 */
public class RemoteServiceException extends ServiceException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String jsonResult;

	public RemoteServiceException(String jsonResult) {
		this.jsonResult = jsonResult;
	}

	/**  
	 * TODO(这里用一句话描述这个方法的作用)
	 * @return: JsonResult
	 */
	public String getJsonResult() {
		return jsonResult;
	}

	
	@Override
	public String getMessage() {
		return getJsonResult();
	}
}
