package com.example.authserver.result.module;


/**
 * 
 * 请求结果状态
 */
public enum JsonResultStateEnums {
	/** 
	 * 成功
	 * 
	 * @Fields SUCCESS
	*/ 
	SUCCESS(200),
	/** 
	 * 失败
	 * 
	 * @Fields ERROR
	*/ 
	ERROR(207),
	/**
	 * 301 rewrite
	 */
	FOUND(302),
	/** 
	 * 无访问权限
	 * 
	 * @Fields FORBIDDEN
	*/ 
	FORBIDDEN(401),
	/** 
	 * 未登录
	 * 
	 * @Fields NO_LOGON
	*/ 
	NO_LOGIN(403),
	/** 
	 * 服务器异常
	 * 
	 * @Fields EXCEPTION
	*/ 
	EXCEPTION(500)
	;
	private int state;
	
	/**
	 * 
	 */
	private JsonResultStateEnums(int state) {
		this.state = state;
	}

	public int getState() {
		return state;
	}
	public static JsonResultStateEnums getByState(int state) {
		for (JsonResultStateEnums v : JsonResultStateEnums.values()) {
			if(v.getState() == state){
				return v;
			}
		}
		
		return null;
	}
	
}
