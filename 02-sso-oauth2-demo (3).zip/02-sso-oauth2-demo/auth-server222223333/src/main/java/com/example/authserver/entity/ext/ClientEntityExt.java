package com.example.authserver.entity.ext;


import com.example.authserver.entity.ClientEntity;

import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.ArrayList;
import java.util.List;

@Table(name = "OAUTH_CLIENT_DETAILS")
public class ClientEntityExt extends ClientEntity {

    @Transient
    private String clientName;
    @Transient
    private List<String>  clientIds;
    @Transient
    private String icon;
    @Transient
    private String color;
    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }


    public List<String> getClientIds() {
        if(clientIds==null){
            clientIds = new ArrayList<String>();
        }
        return clientIds;
    }

    public void setClientIds(List<String> clientIds) {
        this.clientIds = clientIds;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}
