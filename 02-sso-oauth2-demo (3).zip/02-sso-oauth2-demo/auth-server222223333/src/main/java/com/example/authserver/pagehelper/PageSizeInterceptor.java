package com.example.authserver.pagehelper;

import com.github.pagehelper.PageHelper;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


@Aspect
@Component
public class PageSizeInterceptor {
	private static final Logger logger = LoggerFactory.getLogger(PageSizeInterceptor.class);
	private static int pageSize=200;
	private static int pageSizeMax=1000;
	/**
	 * 定义拦截规则：
	 */
	
	@Pointcut("execution(* com.example.authserver.service.*.*(..)) && @annotation(com.example.authserver.pagehelper.PageSize200)")
	public void PageMethodPointcut(){}
	

	
	
	@Around("PageMethodPointcut()") 
	public Object Interceptor(ProceedingJoinPoint joinPoint) throws Throwable {

	    	int page=0;
	    	Object[] args = joinPoint.getArgs();
	    	if(args.length>0){
				if(args[0] instanceof Page){
					page = ((Page) args[0]).getPageNo();
				}
	    	}
	    	int thisPageSize=pageSize;
	    	if(((Page) args[0]).getPageSize()< pageSizeMax&&((Page) args[0]).getPageSize()>1)
	    	{
	    		thisPageSize=((Page) args[0]).getPageSize();
	    	}
	    	PageHelper.startPage(page, thisPageSize);
	        Object obj = joinPoint.proceed();  
	        return obj;  

		
		
	}
	}
