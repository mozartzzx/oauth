package com.example.authserver.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.Principal;

@RestController
@RequestMapping(value = "user")
public class UserController {
        @RequestMapping(value = "info")
        public Principal me(Principal principal) {
            System.out.println("调用info接口获取用户信息：" + principal);
            return principal;
        }

}

