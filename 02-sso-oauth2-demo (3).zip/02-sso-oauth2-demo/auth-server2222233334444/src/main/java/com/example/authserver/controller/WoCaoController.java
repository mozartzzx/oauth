package com.example.authserver.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.Principal;

@RestController
@RequestMapping(value = "wocao")
public class WoCaoController {
        @RequestMapping(value = "info")
        public String me(Test tt) {
            System.out.println("调用info接口获取用户信息：" + tt);
            return tt.toString();
        }

}

