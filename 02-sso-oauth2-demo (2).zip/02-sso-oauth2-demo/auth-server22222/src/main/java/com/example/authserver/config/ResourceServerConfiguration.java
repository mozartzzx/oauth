package com.example.authserver.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;

/**
 *  @EnableResourceServer  受限资源需要携带token访问
 *  如果统一认证的服务 是一个单独的服务，即只提供认证不会作为资源服务
 *  那么这个文件可以不用写
 *  直接在启动类上加 @EnableResourceServer
 *  请求优先由 @EnableAuthorizationServer - > @EnableResourceServer 处理 ->剩下的无法匹配的由SpringSecurity处理。
 *
 *   如果认证与资源并存
 *   对外提供的 user/info 必须需要受限，等于验证了一下携带的token
 *   oauth认证的需要受限
 *   其他的资源api可以不受限
 */
@Configuration
@EnableResourceServer
public class ResourceServerConfiguration extends ResourceServerConfigurerAdapter {
    
    @Value("${resource.id:spring-boot-application}")
    private String resourceId;
    
    @Override
    public void configure(ResourceServerSecurityConfigurer resources) {
        // @formatter:off
        resources.resourceId(resourceId);
        // @formatter:on
    }

    @Override
    public void configure(HttpSecurity http) throws Exception {
        // @formatter:off
        	http/*.antMatcher("").requestMatcher(new OAuth2RequestedMatcher())*/
                .antMatcher("/user/me").authorizeRequests()
                	//.antMatchers(HttpMethod.OPTIONS).permitAll()
                	.antMatchers("/user/me").authenticated();
        // @formatter:on
    }
    
    /**
     * 定义一个oauth2的请求匹配器
     * @author leftso
     *
     */
    /*private static class OAuth2RequestedMatcher implements RequestMatcher {
        @Override
    	public boolean matches(HttpServletRequest request) {
            String auth = request.getHeader("Authorization");
            //判断来源请求是否包含oauth2授权信息,这里授权信息来源可能是头部的Authorization值以Bearer开头,或者是请求参数中包含access_token参数,满足其中一个则匹配成功
            boolean haveOauth2Token = (auth != null) && auth.startsWith("Bearer");
            boolean haveAccessToken = request.getParameter("access_token")!=null;
			return haveOauth2Token || haveAccessToken;
        }
    }*/

}
