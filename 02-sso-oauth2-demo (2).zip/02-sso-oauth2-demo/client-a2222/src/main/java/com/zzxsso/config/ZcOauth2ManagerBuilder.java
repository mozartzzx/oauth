package com.zzxsso.config;

import org.springframework.boot.autoconfigure.security.oauth2.resource.UserInfoTokenServices;
import org.springframework.context.ApplicationContext;
import org.springframework.security.oauth2.client.DefaultOAuth2ClientContext;
import org.springframework.security.oauth2.client.OAuth2ClientContext;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.filter.OAuth2ClientAuthenticationProcessingFilter;
import org.springframework.security.oauth2.client.token.AccessTokenRequest;
import org.springframework.security.oauth2.provider.token.ResourceServerTokenServices;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import java.util.*;


public class ZcOauth2ManagerBuilder {

    private String[] prepertiesprefix;

    private ApplicationContext applicationContext;



    private ClientResourceProperty clientResourceProperty;

    private Map<String, ResourceServerTokenServices> resourceServerTokenServices =new HashMap<String, ResourceServerTokenServices>();

    private Map<String, OAuth2ClientAuthenticationProcessingFilter> filters = new HashMap<String, OAuth2ClientAuthenticationProcessingFilter>();




    public String[] getPrepertiesprefix() {
        return prepertiesprefix;
    }

    public void setPrepertiesprefix(String[] prepertiesprefix) {
        this.prepertiesprefix = prepertiesprefix;
    }




    public ApplicationContext getApplicationContext() {
        return applicationContext;
    }

    public void setApplicationContext(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }





    public ClientResourceProperty getClientResourceProperty() {
        return clientResourceProperty;
    }

    public void setClientResourceProperty(ClientResourceProperty clientResourceProperty) {
        this.clientResourceProperty = clientResourceProperty;
    }




    public void init(){

        AccessTokenRequest accessTokenRequest = applicationContext.getBean(AccessTokenRequest.class);
        //oAuth2ClientContext = /accessTokenRequest;
        Map<String, ClientResourceProperty.ClientResource> servers = clientResourceProperty.getCustom();
        Assert.notEmpty(servers,"yaml config not exits");
        if(servers!=null&&!servers.isEmpty()){
            for(String key:servers.keySet()){
                OAuth2ClientContext oAuth2ClientContext = new DefaultOAuth2ClientContext(accessTokenRequest);
                OAuth2RestTemplate rest = new OAuth2RestTemplate(servers.get(key).getClient(),oAuth2ClientContext);
                RemoteRest.put(key,rest);
                UserInfoTokenServices userInfoTokenServices = new UserInfoTokenServices(servers.get(key).getResource().getUserInfoUri(), servers.get(key).getClient().getClientId());
                userInfoTokenServices.setRestTemplate(rest);
                resourceServerTokenServices.put(key,userInfoTokenServices);
                OAuth2ClientAuthenticationProcessingFilter filter = new OAuth2ClientAuthenticationProcessingFilter(
                        clientResourceProperty.getCustom().get(key).getLoginPath());
                filter.setRestTemplate(rest);
                filter.setTokenServices(userInfoTokenServices);
                filter.setApplicationEventPublisher(this.applicationContext);
                filters.put(key,filter);
               /* UserInfoTokenServices userInfoTokenServices = new UserInfoTokenServices(servers.get(key).getResource().getUserInfoUri(), servers.get(key).getClient().getClientId());
                resourceServerTokenServices.put(key,userInfoTokenServices);
                OAuth2ClientContext oAuth2ClientContext = new DefaultOAuth2ClientContext(accessTokenRequest);
                OAuth2RestTemplate rest = new OAuth2RestTemplate(servers.get(key).getClient(),oAuth2ClientContext);
                RemoteRest.put(key,rest);
                OAuth2ClientAuthenticationProcessingFilter filter = new OAuth2ClientAuthenticationProcessingFilter(
                        clientResourceProperty.getCustom().get(key).getLoginPath());
                filter.setRestTemplate(rest);
                filter.setTokenServices(userInfoTokenServices);
                filter.setApplicationEventPublisher(this.applicationContext);
                filters.put(key,filter);*/
            }


        }
    }

    public ResourceServerTokenServices getTokenServices(String key){
        return resourceServerTokenServices.get(key);
    }
    public OAuth2ClientAuthenticationProcessingFilter getFilter(String key){
        return filters.get(key);
    }

    public Collection<OAuth2ClientAuthenticationProcessingFilter> buildMachtedFiters(){
        if(prepertiesprefix==null||prepertiesprefix.length==0||(prepertiesprefix.length==1&& StringUtils.isEmpty(prepertiesprefix[0]))){
            return  filters.values();
        }else{
            List<OAuth2ClientAuthenticationProcessingFilter> list = new ArrayList<OAuth2ClientAuthenticationProcessingFilter>();
            for(String key:prepertiesprefix){
                if(filters.containsKey(key)){
                    list.add(filters.get(key));
                }
            }
            Assert.notEmpty(list,"EnableOAuth2SsoCuntom values not match yaml config");
            return list;
        }
    }

}
