package com.zzxsso.config;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportAware;
import org.springframework.core.annotation.AnnotationAttributes;
import org.springframework.core.type.AnnotationMetadata;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.util.ClassUtils;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Method;
import java.util.Map;

@Configuration
public class ZcOAuth2SsoCustomConfiguration implements ImportAware , BeanPostProcessor, ApplicationContextAware {
    private Class<?> configType;

    private ApplicationContext applicationContext;

    @Autowired
    private ClientResourceProperty clientResourceProperty;


    private ZcOauth2ManagerBuilder zcOauth2ManagerBuilder = new ZcOauth2ManagerBuilder();

    public void setImportMetadata(AnnotationMetadata importMetadata) {


        this.configType = ClassUtils.resolveClassName(importMetadata.getClassName(),
                null);

        Map<String, Object> enableWebSecurityAttrMap = importMetadata
                .getAnnotationAttributes(EnableOAuth2SsoCuntom.class.getName());
        AnnotationAttributes enableWebSecurityAttrs = AnnotationAttributes
                .fromMap(enableWebSecurityAttrMap);
        zcOauth2ManagerBuilder.setClientResourceProperty(clientResourceProperty);
        zcOauth2ManagerBuilder.setPrepertiesprefix(enableWebSecurityAttrs.getStringArray("value"));

    }


    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
        zcOauth2ManagerBuilder.setApplicationContext(applicationContext);

    }


    public Object postProcessBeforeInitialization(Object bean, String beanName)
            throws BeansException {
        return bean;
    }


    public Object postProcessAfterInitialization(Object bean, String beanName)
            throws BeansException {
        if (this.configType.isAssignableFrom(bean.getClass())
                && bean instanceof WebSecurityConfigurerAdapter) {
            ProxyFactory factory = new ProxyFactory();
            factory.setTarget(bean);
            factory.addAdvice(new ZcOAuth2SsoCustomConfiguration.SsoSecurityAdapter(this.applicationContext,zcOauth2ManagerBuilder));
            bean = factory.getProxy();
        }
        return bean;
        //return bean;
    }

    private static class SsoSecurityAdapter implements MethodInterceptor {

        private ZcSsoSecurityConfigurer configurer;

        SsoSecurityAdapter(ApplicationContext applicationContext,ZcOauth2ManagerBuilder zcOauth2ManagerBuilder) {
            this.configurer = new ZcSsoSecurityConfigurer(applicationContext,zcOauth2ManagerBuilder);
        }


        public Object invoke(MethodInvocation invocation) throws Throwable {
            if (invocation.getMethod().getName().equals("init")) {
                Method method = ReflectionUtils
                        .findMethod(WebSecurityConfigurerAdapter.class, "getHttp");
                ReflectionUtils.makeAccessible(method);
                HttpSecurity http = (HttpSecurity) ReflectionUtils.invokeMethod(method,
                        invocation.getThis());
                this.configurer.configure(http);
            }
            return invocation.proceed();
        }
    }
}
