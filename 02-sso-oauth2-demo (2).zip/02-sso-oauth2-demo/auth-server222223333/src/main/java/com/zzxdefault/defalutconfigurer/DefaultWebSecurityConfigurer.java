package com.zzxdefault.defalutconfigurer;

import com.zzxdefault.security.access.DefaultAccessDecisionManager;
import com.zzxdefault.security.config.UserAuthenticationConfiguration;
import com.zzxdefault.security.config.UserAuthorizationConfig;
import com.zzxdefault.security.service.UserAuthorizationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;


@Configuration
@ConditionalOnProperty( name = "app.sso",havingValue = "false",matchIfMissing = true)
@Import({UserAuthenticationConfiguration.class})
public class DefaultWebSecurityConfigurer extends WebSecurityConfigurerAdapter {

    @Autowired(required = false)
    private UserAuthorizationService userAuthorizationService;

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        super.configure(auth);

    }

    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring()
                .antMatchers("/static/**");
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {

        if(userAuthorizationService!=null){
            http.authorizeRequests().withObjectPostProcessor
                    (new UserAuthorizationConfig.FilterSecurityInterceptorPostProcessor(userAuthorizationService))
                    .accessDecisionManager(new DefaultAccessDecisionManager(userAuthorizationService)).antMatchers("/","/login**")
                    .permitAll().anyRequest().authenticated();

        }else{
            http.authorizeRequests().antMatchers("/","/login**")
                    .permitAll().anyRequest().authenticated();
        }
        http
                /**
                 * formLogin 是加入 FormLoginConfigurer 表单认证的配置
                 * FormLoginConfigurer及其父类AbstractAuthenticationFilterConfigurer
                 * 主要是配置生成UsernamePasswordAuthenticationFilter
                 */
                .formLogin()
                /**
                 * 自定义登录验证的接口
                 *      AbstractAuthenticationProcessingFilter 认证过滤器，使用其子类UsernamePasswordAuthenticationFilter尝试认证
                 *
                 *      在UsernamePasswordAuthenticationFilter过滤器执行的时候
                 *          主要是其继承的AbstractAuthenticationProcessingFilter doFilter
                 *          过滤器执行的时候，requiresAuthentication（..）判断请求是否是验证登录的请求路径，如果不是，就执行后面的过滤器
                 *          如果是，则由AbstractAuthenticationProcessingFilter的子类即UsernamePasswordAuthenticationFilter
                 *          attemptAuthentication（..） 尝试认证
                 *
                 *          requiresAuthentication（..）判断请求是否是验证登录的请求路径的时候
                 *          是使用RequestMatcher验证请求是否匹配
                 *          默认是 new AntPathRequestMatcher("/login", "POST")
                 *          通过 下面自定义登录验证的接口 可以修改RequestMatcher，从而实现判断请求是否是登录认证请求。从而尝试认证
                 */
                //自定义登录验证的接口.loginProcessingUrl("/login")

                /**
                 * UsernamePasswordAuthenticationFilter 在使用attemptAuthentication（ttpServletRequest request,
                 * 			HttpServletResponse response）
                 *  认证的时候，需要冲请求中获取 用户名和密码
                 *  默认是request.getParameter(usernameParameter) -- "username"属性获取用户名
                 *       request.getParameter(passwordParameter) -- "password"属性获取密码
                 *  默认值为什么是上面两个，后面一起讲了
                 *  通过下面的 自定义登录用户名属性 和 自定义登录密码属性 进行修改
                 */
                //自定义登录用户名属性.usernameParameter("username")
                //自定义登录密码属性.passwordParameter("password")

                /**
                 * 在UsernamePasswordAuthenticationFilter及其父类AbstractAuthenticationProcessingFilter
                 * 认证成功或者失败后，会交给AbstractAuthenticationProcessingFilter的下面两个处理器处理
                 * AuthenticationSuccessHandler
                 * AuthenticationFailureHandler
                 *
                 *在FormLoginConfigurer默认配置中
                 * 从上面的 formLogin() 中的 new FormLoginConfigurer() 可以看出走的是FormLoginConfigurer的无参构造器
                 *  public FormLoginConfigurer() {
                 *         super(new UsernamePasswordAuthenticationFilter(), (String)null);
                 *         this.usernameParameter("username");
                 *         this.passwordParameter("password");
                 *  }
                 * super指的就是AbstractAuthenticationFilterConfigurer
                 *
                 * 进AbstractAuthenticationFilterConfigurer可以看出默认的successHandler是SavedRequestAwareAuthenticationSuccessHandler
                 *
                 * 默认失败的处理器加载
                 * 在AbstractAuthenticationFilterConfigurer的init(B http)方法中
                 *  public void init(B http) throws Exception {
                 *         this.updateAuthenticationDefaults();
                 *         this.updateAccessDefaults(http);
                 *         this.registerDefaultAuthenticationEntryPoint(http);
                 *     }
                 *  protected final void updateAuthenticationDefaults() {
                 *         if (this.loginProcessingUrl == null) {
                 *             this.loginProcessingUrl(this.loginPage);
                 *         }
                 *
                 *         if (this.failureHandler == null) {
                 *             this.failureUrl(this.loginPage + "?error");
                 *         }
                 *
                 *         LogoutConfigurer<B> logoutConfigurer = (LogoutConfigurer)((HttpSecurityBuilder)this.getBuilder()).getConfigurer(LogoutConfigurer.class);
                 *         if (logoutConfigurer != null && !logoutConfigurer.isCustomLogoutSuccess()) {
                 *             logoutConfigurer.logoutSuccessUrl(this.loginPage + "?logout");
                 *         }
                 *
                 *     }
                 * public final T failureUrl(String authenticationFailureUrl) {
                 *         T result = this.failureHandler(new SimpleUrlAuthenticationFailureHandler(authenticationFailureUrl));
                 *         this.failureUrl = authenticationFailureUrl;
                 *         return result;
                 * }
                 * 可以看出 如果 failureHandler为空时默认使用 SimpleUrlAuthenticationFailureHandler
                 *
                 * 至于init方法什么时候执行的，
                 * public FormLoginConfigurer<HttpSecurity> formLogin() throws Exception {
                 *         return (FormLoginConfigurer)this.getOrApply(new FormLoginConfigurer());
                 * }
                 * 上面的 http.formLogin()的时候 把FormLoginConfigurer配置加入了 HttpSecurity配置的集合中
                 * 在 HttpSecurity bulid的时候里面执行的
                 *
                 * 通过下面的自定义登录验证失败重定向的地址和自定义登录验证成功重定向的地址
                 * 加入的是 ForwardAuthenticationFailureHandler
                 *
                 */
                //自定义登录验证失败重定向的地址.failureForwardUrl("/login?error")
                //自定义登录验证成功重定向的地址.successForwardUrl("/index")

                /**
                 * 自定义登录验证入口地址
                 * 这个入口地址，是用来引导用户去登录页面的；也就是你没登录的时候就访问，浏览器会跳转到登入页面
                 *
                 * 默认值还是从.formLogin()的时候找
                 * 从FormLoginConfigurer的父类AbstractAuthenticationFilterConfigurer
                 * 可以发现
                 *  protected AbstractAuthenticationFilterConfigurer() {
                 *         this.defaultSuccessHandler = new SavedRequestAwareAuthenticationSuccessHandler();
                 *         this.successHandler = this.defaultSuccessHandler;
                 *         this.setLoginPage("/login");
                 *     }
                 *
                 *     protected AbstractAuthenticationFilterConfigurer(F authenticationFilter, String defaultLoginProcessingUrl) {
                 *         this();
                 *         this.authFilter = authenticationFilter;
                 *         if (defaultLoginProcessingUrl != null) {
                 *             this.loginProcessingUrl(defaultLoginProcessingUrl);
                 *         }
                 *
                 *     }
                 *
                 *   private void setLoginPage(String loginPage) {
                 *         this.loginPage = loginPage;
                 *         this.authenticationEntryPoint = new LoginUrlAuthenticationEntryPoint(loginPage);
                 *   }
                 *   默认值就是 LoginUrlAuthenticationEntryPoint
                 *
                 *   那这个东西在哪使用的呢？
                 *   实在后面的一个叫ExceptionTranslationFilter过滤器中使用的
                 *
                 *   在AbstractAuthenticationFilterConfigurer的init(B http)方法中
                 *      public void init(B http) throws Exception {
                 *         this.updateAuthenticationDefaults();
                 *         this.updateAccessDefaults(http);
                 *         this.registerDefaultAuthenticationEntryPoint(http);
                 *     }
                 *      protected final void registerAuthenticationEntryPoint(B http, AuthenticationEntryPoint authenticationEntryPoint) {
                 *         ExceptionHandlingConfigurer<B> exceptionHandling = (ExceptionHandlingConfigurer)http.getConfigurer(ExceptionHandlingConfigurer.class);
                 *         if (exceptionHandling != null) {
                 *             exceptionHandling.defaultAuthenticationEntryPointFor((AuthenticationEntryPoint)this.postProcess(authenticationEntryPoint), this.getAuthenticationEntryPointMatcher(http));
                 *         }
                 *     }
                 *  有一个 registerDefaultAuthenticationEntryPoint 注册默认的认证入口
                 *  就是在给 ExceptionTranslationFilter对应的配置类 ExceptionHandlingConfigurer 增加AuthenticationEntryPoint
                 *  ExceptionHandlingConfigurer中的defaultAuthenticationEntryPointFor方法，其实是将AuthenticationEntryPoint和RequestMatcher加入到
                 *  他的
                 *  LinkedHashMap<RequestMatcher, AuthenticationEntryPoint> defaultEntryPointMappings 集合中去
                 *  通过ExceptionHandlingConfigurer的configure(H http)方法
                 *  可以看到
                 *  public void configure(H http) throws Exception {
                 *         AuthenticationEntryPoint entryPoint = this.getAuthenticationEntryPoint(http);
                 *         ExceptionTranslationFilter exceptionTranslationFilter = new ExceptionTranslationFilter(entryPoint, this.getRequestCache(http));
                 *         AccessDeniedHandler deniedHandler = this.getAccessDeniedHandler(http);
                 *         exceptionTranslationFilter.setAccessDeniedHandler(deniedHandler);
                 *         exceptionTranslationFilter = (ExceptionTranslationFilter)this.postProcess(exceptionTranslationFilter);
                 *         http.addFilter(exceptionTranslationFilter);
                 *     }
                 *  ExceptionTranslationFilter使用的AuthenticationEntryPoint
                 *  是通过其this.getAuthenticationEntryPoint(http)获取的
                 *  接着看源码
                 *  AuthenticationEntryPoint getAuthenticationEntryPoint(H http) {
                 *         AuthenticationEntryPoint entryPoint = this.authenticationEntryPoint;
                 *         if (entryPoint == null) {
                 *             entryPoint = this.createDefaultEntryPoint(http);
                 *         }
                 *
                 *         return entryPoint;
                 *  }
                 *  如果ExceptionHandlingConfigurer的authenticationEntryPoint存在就用它
                 *  如果不存在就创建
                 *  默认情况下是不存在的
                 *  进入this.createDefaultEntryPoint(http);方法
                 *  private AuthenticationEntryPoint createDefaultEntryPoint(H http) {
                 *         if (this.defaultEntryPointMappings.isEmpty()) {
                 *             return new Http403ForbiddenEntryPoint();
                 *         } else if (this.defaultEntryPointMappings.size() == 1) {
                 *             return (AuthenticationEntryPoint)this.defaultEntryPointMappings.values().iterator().next();
                 *         } else {
                 *             DelegatingAuthenticationEntryPoint entryPoint = new DelegatingAuthenticationEntryPoint(this.defaultEntryPointMappings);
                 *             entryPoint.setDefaultEntryPoint((AuthenticationEntryPoint)this.defaultEntryPointMappings.values().iterator().next());
                 *             return entryPoint;
                 *         }
                 *     }
                 * 可以看出，根据defaultEntryPointMappings大小不同，创建的AuthenticationEntryPoint不同
                 * 如果大于1，创建DelegatingAuthenticationEntryPoint 是一个委派的模式
                 * ExceptionTranslationFilter在处理异常的时候 有一个 sendStartAuthentication方法
                 *  protected void sendStartAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chain, AuthenticationException reason) throws ServletException, IOException {
                 *         SecurityContextHolder.getContext().setAuthentication((Authentication)null);
                 *         this.requestCache.saveRequest(request, response);
                 *         this.logger.debug("Calling Authentication entry point.");
                 *         this.authenticationEntryPoint.commence(request, response, reason);
                 *     }
                 * 就会给ExceptionTranslationFilter的authenticationEntryPoint着手
                 *如果是DelegatingAuthenticationEntryPoint，那么会对请求进行匹配，最终决定交给哪个AuthenticationEntryPoint着手
                 *
                 *
                 * 通过  自定义登录验证入口地址 配置的是改变
                 * FormLoginConfigurer的中的 LoginUrlAuthenticationEntryPoint跳转的地址
                 */
                //自定义登录验证入口地址.loginPage("/login")
                //.permitAll()
                //.and()
                //.logout()
                //.logoutUrl("/logout")
                //.logoutSuccessUrl("/index")
                //.permitAll()
                .successForwardUrl("/securedPage")
                .and()
                .httpBasic().and().csrf().disable()
        ;

    }



}
