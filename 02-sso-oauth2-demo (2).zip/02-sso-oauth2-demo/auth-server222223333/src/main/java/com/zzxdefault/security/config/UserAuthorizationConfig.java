package com.zzxdefault.security.config;

import com.zzxdefault.security.access.DefaultFilterInvocationSecurityMetadataSource;
import com.zzxdefault.security.service.UserAuthorizationService;
import org.springframework.security.config.annotation.ObjectPostProcessor;
import org.springframework.security.web.access.intercept.FilterSecurityInterceptor;


public class UserAuthorizationConfig {




    public static class FilterSecurityInterceptorPostProcessor implements ObjectPostProcessor<FilterSecurityInterceptor>{
        private UserAuthorizationService userAuthorizationService;

        public FilterSecurityInterceptorPostProcessor(UserAuthorizationService userAuthorizationService){
            this.userAuthorizationService = userAuthorizationService;
        }
        @Override
        public <O extends FilterSecurityInterceptor> O postProcess(O fsi) {
            fsi.setSecurityMetadataSource(new DefaultFilterInvocationSecurityMetadataSource(userAuthorizationService,fsi.getSecurityMetadataSource())) ;
            return fsi;
        }
    }

}
