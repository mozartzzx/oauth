package com.zzxdefault.security.service;

import org.springframework.security.core.userdetails.UserDetails;

public interface UserRelationService {
    /**
     * 根据用户名获取用户
     * @param username
     * @return
     */
    UserDetails loadUserByUsername(String username);

    /**
     * 加密密码
     * @param password 前端传来的密码
     * @return
     */
    String encrypt(String password);

    /**
     * @param encodedPassword  encrypt加密后的密码
     * @param rawPasswordEncoded  数据里里的
     * 对比两个密码是否一致 其实用个equals就好了
     * 当然也可以用 EncryptUtil中的equals方法
     * @return
     */
    boolean matchePassword(String encodedPassword, String rawPasswordEncoded);
}
