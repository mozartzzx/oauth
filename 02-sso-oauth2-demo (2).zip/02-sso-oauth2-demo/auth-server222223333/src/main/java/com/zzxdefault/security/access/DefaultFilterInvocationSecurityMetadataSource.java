package com.zzxdefault.security.access;

import com.zzxdefault.security.service.UserAuthorizationService;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.access.SecurityConfig;
import org.springframework.security.web.FilterInvocation;
import org.springframework.security.web.access.intercept.FilterInvocationSecurityMetadataSource;
import org.springframework.util.AntPathMatcher;

import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class DefaultFilterInvocationSecurityMetadataSource implements FilterInvocationSecurityMetadataSource {

        private FilterInvocationSecurityMetadataSource  superMetadataSource;
         /**
          * 如果系统是将url的访问权限配置在数据库中的，那么就实现userAuthorizationService的loadSecurityMetadataSource
          * 获取系统数据库中维护的url和访问权限的关系
          */
        private UserAuthorizationService userAuthorizationService;

         // 这里的需要从DB加载 或者项目启动就生成
        /*
                private   Map<String,String> urlRoleMap = new HashMap<String,String>(){{
                    put("/open/**","ROLE_ANONYMOUS");
                    put("/health","ROLE_ANONYMOUS");
                    put("/restart","ROLE_ADMIN");
                    put("/demo","ROLE_USER");
                }};
        */
        public static ConcurrentHashMap<String,String> urlRoleMap;
        @Override
        public Collection<ConfigAttribute> getAllConfigAttributes() {
            return null;
        }

        public DefaultFilterInvocationSecurityMetadataSource(UserAuthorizationService userAuthorizationService, FilterInvocationSecurityMetadataSource expressionBasedFilterInvocationSecurityMetadataSource){
            this.userAuthorizationService = userAuthorizationService;
            this.superMetadataSource = expressionBasedFilterInvocationSecurityMetadataSource;


            if(userAuthorizationService!=null){
                //从数据库加载权限配置
                urlRoleMap = userAuthorizationService.loadSecurityMetadataSource();
            }

        }

         public FilterInvocationSecurityMetadataSource getSuperMetadataSource() {
             return superMetadataSource;
         }

         public void setSuperMetadataSource(FilterInvocationSecurityMetadataSource superMetadataSource) {
             this.superMetadataSource = superMetadataSource;
         }

         private final AntPathMatcher antPathMatcher = new AntPathMatcher();



        @Override
        public Collection<ConfigAttribute> getAttributes(Object object) throws IllegalArgumentException {
            FilterInvocation fi = (FilterInvocation) object;
            String url = fi.getRequestUrl();
            if(urlRoleMap!=null&&!urlRoleMap.isEmpty()){
                for(Map.Entry<String,String> entry:urlRoleMap.entrySet()){
                    if(antPathMatcher.match(entry.getKey(),url)){
                        return SecurityConfig.createList(entry.getValue());
                    }
                }
            }
            Collection<ConfigAttribute> cs =null;
            if(userAuthorizationService!=null){
                cs = userAuthorizationService.createCustomSecurityMetadata(url);
            }
           if(cs!=null){
               return  cs;
           }

            //返回代码定义的默认配置
            return superMetadataSource.getAttributes(object);
        }



        @Override
        public boolean supports(Class<?> clazz) {
            return FilterInvocation.class.isAssignableFrom(clazz);
        }
    }