package com.zzxdefault.oauth2.sso.config;

import org.springframework.context.annotation.Import;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableOAuth2Client;

import java.lang.annotation.*;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@EnableOAuth2Client
@Import({ZcOAuth2SsoCustomConfiguration.class })
public @interface EnableOAuth2SsoCuntom {
	String[] value() default "";
}