package com.zzxdefault.authorizationserver.tokenstore;




import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.security.oauth2.provider.token.AccessTokenConverter;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.InMemoryTokenStore;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.store.JwtTokenStore;
import org.springframework.security.oauth2.provider.token.store.redis.RedisTokenStore;
import org.springframework.util.Assert;

/**
 * TokenStoreConfigurer
 * @author zzx
 * @date 2019/10/14
 */
public class TokenStoreConfigurer {

	private static final String TOKENSOTRE_TYPE_JWT="jwt";
	private static final String TOKENSOTRE_TYPE_REDIS="redis";
	private static final String TOKENSOTRE_TYPE_INMEMORY="inmemory";
	private String tokenStoreType;
	private TokenStoreManager tokenStoreManager = new TokenStoreManager() {
		public void configer(RedisTokenStore redisTokenStore) {
		}
		public AccessTokenConverter getAccessTokenConverter() {
			return null;
		}
	};

	public TokenStoreManager getTokenStoreManager() {
		return tokenStoreManager;
	}

	public void setTokenStoreManager(TokenStoreManager tokenStoreManager) {
		if(tokenStoreManager==null){
			return;
		}
		this.tokenStoreManager = tokenStoreManager;
	}

	public String getTokenStoreType() {
		return tokenStoreType;
	}

	public void setTokenStoreType(String tokenStoreType) {
		this.tokenStoreType = tokenStoreType;
	}

	public RedisConnectionFactory getRedisConnectionFactory() {
		return redisConnectionFactory;
	}

	public void setRedisConnectionFactory(RedisConnectionFactory redisConnectionFactory) {
		this.redisConnectionFactory = redisConnectionFactory;
	}

	private RedisConnectionFactory redisConnectionFactory;


	public AccessTokenConverter getAccessTokenConverter() {
		return tokenStoreManager.getAccessTokenConverter();
	}



    /**
	 * tokenGranter -- AuthorizationServerTokenServices -- tokenStore
     * TokenStore的作用
     * @return
     */
	public TokenStore tokenStore (){
		if(TOKENSOTRE_TYPE_JWT.equalsIgnoreCase(tokenStoreType)){
			Assert.notNull(getAccessTokenConverter(),"tokenStoreType jwt must set JwtAccessTokenConverter");

			if (getAccessTokenConverter() instanceof JwtAccessTokenConverter) {
				 return new JwtTokenStore((JwtAccessTokenConverter)getAccessTokenConverter());
			}else{
				throw new IllegalArgumentException("accessTokenConverter not instanceofinstanceof JwtAccessTokenConverter");
			}


		}else if(TOKENSOTRE_TYPE_REDIS.equalsIgnoreCase(tokenStoreType)){
			Assert.notNull(redisConnectionFactory,"tokenStoreType redis need redisConnectionFactory");
			RedisTokenStore redisTokenStore = new RedisTokenStore(redisConnectionFactory);
			tokenStoreManager.configer(redisTokenStore);
			/**
			 * 设置自定义的key，即在redis里存token的时候对应的key
			 * 默认是使用DefaultAuthenticationKeyGenerator
			 * DefaultAuthenticationKeyGenerator是包括
			 * 		uesrname 这是登录授权服务的账号的用户名
			 * 		client_id 客户端id
			 * 		scope 客户端的scope
			 *  加密后
			 * 	三个信息的key
			 * 	作为唯一
			 */
			//redisTokenStore.setAuthenticationKeyGenerator(xxxxx);
			/**
			 * 设置自定义的 value 序列化策略
			 */
			//redisTokenStore.setSerializationStrategy(qqqq);
			return redisTokenStore;
		}else  if(TOKENSOTRE_TYPE_INMEMORY.equalsIgnoreCase(tokenStoreType)){
			return new InMemoryTokenStore();
		}
		return  null;

	}
}