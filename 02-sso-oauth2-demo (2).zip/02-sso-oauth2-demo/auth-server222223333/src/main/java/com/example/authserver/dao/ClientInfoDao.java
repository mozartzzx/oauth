package com.example.authserver.dao;

import com.example.authserver.entity.ext.ClientInfoEntityExt;
import com.example.authserver.tkmybatis.GenericDao;

public interface ClientInfoDao extends GenericDao<ClientInfoEntityExt> {

}
