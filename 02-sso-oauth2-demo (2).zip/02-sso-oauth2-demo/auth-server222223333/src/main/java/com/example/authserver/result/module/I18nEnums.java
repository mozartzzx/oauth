package com.example.authserver.result.module;

/**
 *
 * 提示消息国际化的枚举类
 *
 * <br>
 * key 国际化的键，传递给前端，由前端具体进行国际化。 <br>
 * desc 为描述
 *
 * <br>
 * 作者：hhlai <br>
 * 时间：2018年1月17日 上午1:25:09 <br>
 * 最近修改人：hhlai <br>
 * 最近修改时间：2018年1月17日 上午1:25:09 <br>
 * 修改原因：
 */

/**
 * TODO(这里用一句话描述这个类的作用)
 *
 * @version V2.0.0
 * @author jfwan
 * @date 2018年3月6日 下午2:14:25
 *
 * @modifyDesc: (这里填写修改说明)
 * @modifyAuthor: (这里填写最近修改人)
 * @modifyDate: (这里填写最近修改时间)
 *
 */

public enum I18nEnums {
	msg_error_value_repeat(I18nPub.global_msg + "msg_error_value_repeat", "{0}不能重复。", 1),
	login_faild(I18nPub.global_msg + "login_faild", "登录失败,账号和密码不匹配!"),
	msg_error(I18nPub.global_msg + "msg_error", "{0}", 1),
	unknown_exception_error(I18nPub.global_msg + "unknown_exception_error", "出现未知的异常."),
	api_call_faild(I18nPub.global_msg + "api_call_faild", "接口调用失败"),
	develop_error(I18nPub.global_msg + "develop_error", "未按照开发规范进行开发。", 1),
	default_serviceexception_error(I18nPub.global_msg + "default_serviceexception_error", "默认的操作异常."),
	/**
	 * 操作成功.
	 *
	 * @author hhlai
	 */
	success(I18nPub.global_msg + "success", "操作成功."),
	/**
	 * 操作失败.
	 *
	 * @author hhlai
	 */
	error(I18nPub.global_msg + "error", "操作失败."),

	login_not_pass_error(I18nPub.global_msg + "login_not_pass_error", "用户名或密码错误");

		private String key;
	private String desc;
	private int replaceNum;

	I18nEnums(String key, String desc) {
		this.key = key;
		this.desc = desc;
		this.replaceNum = 0;
	}

	I18nEnums(String key, String desc, int replaceNum) {
		this.key = key;
		this.desc = desc;
		this.replaceNum = replaceNum;
	}

	public String getKey() {
		return key;
	}

	public String getDesc() {
		return desc;
	}

	public int getReplaceNum() {
		return replaceNum;
	}

	public final boolean equals(I18nEnums i18nEnums) {
		return this == i18nEnums;
	}

	public static void main(String[] args) {
	}

	public static I18nEnums getEnumsByKey(String key) {

		I18nEnums[] values = values();
		for (I18nEnums i18nEnums : values) {
			if (key.equals(i18nEnums.getKey())) {
				return i18nEnums;
			}
		}
		return null;

	}

}
