/**
 * Copyright (c) 2018. www.sunnyintell.com Inc. All rights reserved.
 * 注意：本内容仅限于宁波舜宇智能科技有限公司内部传阅，禁止外泄以及用于其他的商业目的。否则追究其法律责任。
 */
package com.example.authserver.exception;

import org.apache.commons.lang3.StringUtils;
import org.springframework.dao.NonTransientDataAccessException;

import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 用于解析各数据库的索引key
 * <br>全局使用NonTransientDataAccessException异常进行捕获进入
 * 
 * @version V2.0.0
 * @author hhlai
 * @date 2018年1月27日 下午7:24:47
 *
 * @modifyDesc: (这里填写修改说明)
 * @modifyAuthor: (这里填写最近修改人)
 * @modifyDate: (这里填写最近修改时间)
 *
 */
public class UniqueIndexKeyUtils {
	
	/**
	* <br>通过mycat路由
	* <br>UncategorizedSQLException
	* <br>直接连数据库
	* <br>DuplicateKeyException
	* 
	* @version V2.0.0
	* @author hhlai
	* @date 2018年1月27日 下午8:14:43
	* 
	* @modifyDesc: (这里填写修改说明)
	* @modifyAuthor: (这里填写最近修改人)
	* @modifyDate: (这里填写最近修改时间)
	* 
	*/
	public static Optional<UniqueIndex> getUniqueKey(NonTransientDataAccessException e) {
		String msg = e.getMessage();
		Optional<UniqueIndex> ou = null;
		//尝试解析MycatMysql
		ou = getMycatMysqlUniqueKey(msg);
		if(ou.isPresent()){
			return ou;
		}
		//尝试解析Mysql
		ou = getMySqlUniqueKey(msg);
		if(ou.isPresent()){
			return ou;
		}
		//尝试解析Oracle
		ou = getOracleUniqueKey(msg);
		if(ou.isPresent()){
			return ou;
		}
		//TODO postgresql
		
		//提取模块编号
		
		return ou;
	}
	/**
	 * mysql的异常正则
	 */
	private static Pattern pattern_mysql = Pattern.compile("Duplicate entry '([\\s\\S]*?)' for key '([\\s\\S]*?)'");
	/**
	 * oracle的异常正则
	 */
	private static Pattern pattern_oracle = Pattern.compile(": ORA-00001: [\\s\\S]*? \\(([\\s\\S]*?)\\)");
	
	
	
	/**
	 * 
	* 
	* <br>唯一索引
	* <br>Duplicate entry 'A0001' for key 'U_CMSTEP_00';
	* <br>主键
<br>### Error updating database.  Cause: com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException: Duplicate entry '39b1b477-43c9-4298-919f-8d3d8a6ca9aa' for key 'PRIMARY'
<br>### The error may involve com.sunny.systemconfig.dao.SysOperationLogDao.insertSelective-Inline
<br>### The error occurred while setting parameters
<br>### SQL: INSERT INTO SYS_OPERATIONLOG  ( id,N_COMPANY,C_MODULE,C_OPERATIONTYPE,C_OPERATIONCONTENT,FK_SYS_LOGINLOG,N_USERSTATUS,FK_SYS_USER,FK_SYS_STAFF,C_STAFFWORK,C_STAFFNAME,D_DATE ) VALUES( ?,?,?,?,?,?,?,?,?,?,?,? )
<br>### Cause: com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException: Duplicate entry '39b1b477-43c9-4298-919f-8d3d8a6ca9aa' for key 'PRIMARY'
<br>; SQL []; Duplicate entry '39b1b477-43c9-4298-919f-8d3d8a6ca9aa' for key 'PRIMARY'; nested exception is com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException: Duplicate entry '39b1b477-43c9-4298-919f-8d3d8a6ca9aa' for key 'PRIMARY'
	* 
	* @param msg
	* 
	* @version V2.0.0
	* @author hhlai
	* @date 2018年1月29日 下午3:43:14
	* 
	* @modifyDesc: (这里填写修改说明)
	* @modifyAuthor: (这里填写最近修改人)
	* @modifyDate: (这里填写最近修改时间)
	*
	 */
	private static Optional<UniqueIndex> getMySqlUniqueKey(String msg) {
        Matcher matcher = pattern_mysql.matcher(msg);
        
        UniqueIndex ui = null;
        if (matcher.find()) {
            matcher.reset();
            String temp;
            while (matcher.find()) {
            	ui = new UniqueIndex();
            	temp = matcher.group(1);
            	ui.setVal(temp);
                temp = matcher.group(2);
                ui.setKey(temp.toLowerCase());
                
                
                String[] tempArr = ui.getKey().split("_");
            	if(tempArr.length==3&& StringUtils.equals(tempArr[0], "u")){
            		temp = tempArr[1];
            		ui.setMod(temp);
            	}else if(tempArr.length==1&&StringUtils.equals(tempArr[0], "primary")){
            		//ui.setMod(tempArr[0]);
            	}else{
            		ui = null;
            	}
            	
                break;
            }
        }
        return Optional.ofNullable(ui);
	}
	public static void main(String[] args) {
		String mm = "Duplicate entry '39b1b477-43c9-4298-919f-8d3d8a6ca9aa' for key 'U_CMSTEP_00';";
		getMySqlUniqueKey(mm);
		
		mm = "java.sql.SQLIntegrityConstraintViolationException: ORA-00001: 违反唯一约束条件 (SAP.U_CMSTEP_00)"
				+ "\njava.sql.SQLIntegrityConstraintViolationException: ORA-00001: 违反唯一约束条件 (SAP.U_CMSTEP_00)";
		getOracleUniqueKey(mm);
	}
	/**
	 * 
	* 解析mycat-mysql的异常信息，获取key
	* 
	* @param e
	* 
	* @version V2.0.0
	* @author hhlai
	* @date 2018年1月27日 下午8:35:37
	* 
	* @modifyDesc: (这里填写修改说明)
	* @modifyAuthor: (这里填写最近修改人)
	* @modifyDate: (这里填写最近修改时间)
	*
	 */
	private static Optional<UniqueIndex> getMycatMysqlUniqueKey(String msg) {
		return getMySqlUniqueKey(msg);
	}
	
	/**
	 * 
	* SAP.U_CMSTEP_00
	* SAP.PK_CMSTEP
	* 
	* @param msg
	* @return
	* 
	* @version V2.0.0
	* @author hhlai
	* @date 2018年1月29日 下午10:49:54
	* 
	* @modifyDesc: (这里填写修改说明)
	* @modifyAuthor: (这里填写最近修改人)
	* @modifyDate: (这里填写最近修改时间)
	*
	 */
	private static Optional<UniqueIndex> getOracleUniqueKey(String msg) {
        Matcher matcher = pattern_oracle.matcher(msg);
        
        UniqueIndex ui = null;
        if (matcher.find()) {
            matcher.reset();
            String temp;
            while (matcher.find()) {
            	ui = new UniqueIndex();
            	temp = matcher.group(1);//SAP.U_CMSTEP_00
            	String[] tempArr = temp.split("\\.");
            	if(tempArr.length==2){
            		ui.setKey(tempArr[1].toLowerCase());
            	}else if(tempArr.length==1){
            		ui.setKey(tempArr[0].toLowerCase());
            	}else{//0或者3
            		ui = null;
            		break;
            	}
            	
            	tempArr = ui.getKey().split("_");
            	//U_CMSTEP_00
            	if(tempArr.length==3&&StringUtils.equals(tempArr[0], "u")){
            		temp = tempArr[1];
            		ui.setMod(temp);
            	}else if(tempArr.length==3&&StringUtils.equals(tempArr[0], "pk")){//PK_CMSTEP
            		temp = tempArr[1];
            		ui.setMod(temp);
            	}else{
					temp = tempArr[0];
					ui.setMod("without");
            		break;
            	}
            	
                break;
            }
        }
        return Optional.ofNullable(ui);
	}
}