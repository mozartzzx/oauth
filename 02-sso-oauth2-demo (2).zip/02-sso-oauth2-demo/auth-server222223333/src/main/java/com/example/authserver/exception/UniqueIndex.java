/**
 * Copyright (c) 2018. www.sunnyintell.com Inc. All rights reserved.
 * 注意：本内容仅限于宁波舜宇智能科技有限公司内部传阅，禁止外泄以及用于其他的商业目的。否则追究其法律责任。
 */
package com.example.authserver.exception;

/**
 * 
 * 索引对象
 * 
 * @version V2.0.0
 * @author hhlai
 * @date 2018年1月29日 下午3:13:08
 *
 * @modifyDesc: (这里填写修改说明)
 * @modifyAuthor: (这里填写最近修改人)
 * @modifyDate: (这里填写最近修改时间)
 *
 */
public class UniqueIndex {
	/**
	 * 表的编号：去下划线
	 */
	private String mod;
	/**
	 * 唯一索引key
	 */
	private String key;
	/**
	 * 值，只有mysql
	 */
	private String val;
	/**  
	 * 
	 * @return: String
	 */
	public String getKey() {
		return key;
	}
	/**  
	 * 
	 * @param: key
	 * @return: String
	 */
	public void setKey(String key) {
		this.key = key;
	}
	/**  
	 * 
	 * @return: String
	 */
	public String getVal() {
		return val;
	}
	/**  
	 * 
	 * @param: val
	 * @return: String
	 */
	public void setVal(String val) {
		this.val = val;
	}
	/**  
	 * 
	 * @return: String
	 */
	public String getMod() {
		return mod;
	}
	/**  
	 * 
	 * @param: mod
	 * @return: String
	 */
	public void setMod(String mod) {
		this.mod = mod;
	}
	
	
}
