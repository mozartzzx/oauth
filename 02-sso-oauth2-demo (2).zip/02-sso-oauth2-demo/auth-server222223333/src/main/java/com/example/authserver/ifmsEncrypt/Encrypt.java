package com.example.authserver.ifmsEncrypt;

import com.alibaba.fastjson.JSONObject;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author yjweng
 * @version 1.0
 * 安全加密类，目前仅支持MD5
 */

public class Encrypt {

    /**
     * 本方法用于对传入的明文进行MD5加密
     *
     * @param string 需要加密的明文
     * @return 加密后的密文
     * @throws NoSuchAlgorithmException
     * @throws UnsupportedEncodingException
     */
    public static String encryptByMD5(String string) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        MessageDigest messageDigest = MessageDigest.getInstance("md5");
        messageDigest.update(string.getBytes("UTF-8"));
        return new BigInteger(1, messageDigest.digest()).toString(16);
    }

    public static String encryptByBase64(String string) {
        return new String(Base64.getEncoder().encode(string.getBytes()));
    }

    public static String signature(byte[] bytes) throws NoSuchAlgorithmException {
        MessageDigest sha1 = MessageDigest.getInstance("SHA1");
        sha1.update(bytes);
        byte[] sha1Result = sha1.digest();
        return new BigInteger(1, sha1Result).toString(16);
    }

    public static String signAsSetList(Set<Map.Entry<String,List<String>>> entrySet) throws Exception {
        String body = JSONObject.toJSONString(entrySet);
        return signature(body.getBytes("UTF-8"));
    }

    public static String signAsSetArray(Set<Map.Entry<String, String[]>> set) throws Exception {
        String body = JSONObject.toJSONString(set);
        return signature(body.getBytes("UTF-8"));
    }
    public static void main(String[] args) throws Exception {
    	MultiValueMap<String, String> postParameters = new LinkedMultiValueMap<String, String>();
       
            postParameters.add("jsonStr", "{\"age\":15}");
            System.out.println(JSONObject.toJSONString(postParameters.entrySet()));
		System.out.println(signAsSetList(postParameters.entrySet()));
		System.out.println(signature("\"123\"".getBytes("UTF-8")));
		//System.out.println(UUID.randomUUID().toString());
	}
}
