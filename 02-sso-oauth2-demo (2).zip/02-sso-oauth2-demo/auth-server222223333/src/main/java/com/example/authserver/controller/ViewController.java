package com.example.authserver.controller;

import com.example.authserver.entity.ClientEntity;
import com.example.authserver.entity.UserEntity;
import com.example.authserver.entity.ext.ClientEntityExt;
import com.example.authserver.result.module.JsonResult;
import com.example.authserver.result.module.JsonResultUtils;
import com.example.authserver.service.ClientService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@RestController
@RequestMapping(value = "/api/client")
public class ViewController {
    @Resource
    private ClientService clientService;


    @RequestMapping(value = "/select/infolist")
    public JsonResult infolist( ) {


       List<ClientEntityExt> clientEntity = clientService.infolist();

        return JsonResultUtils.getJsonResultSuccess(clientEntity);
    }

    @RequestMapping(value = "/insert/insert")
    public JsonResult insert( ClientEntityExt clientEntityExt) {


        clientService.addClient(clientEntityExt);

        return JsonResultUtils.getJsonResultSuccess();
    }
    @RequestMapping(value = "/delete/delete")
    public JsonResult delete(List<ClientEntityExt> clientEntityExtList) {


        clientService.deleteClients(clientEntityExtList);

        return JsonResultUtils.getJsonResultSuccess();
    }
    @RequestMapping(value = "/update/update")
    public JsonResult update(ClientEntityExt  clientEntityExt) {


        clientService.updateClient(clientEntityExt);


        return JsonResultUtils.getJsonResultSuccess();
    }
}
