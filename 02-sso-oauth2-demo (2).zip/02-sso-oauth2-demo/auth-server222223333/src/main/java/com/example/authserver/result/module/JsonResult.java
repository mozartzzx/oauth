/**
 * Copyright (c) 2018. www.sunnyintell.com Inc. All rights reserved.
 * 注意：本内容仅限于宁波舜宇智能科技有限公司内部传阅，禁止外泄以及用于其他的商业目的。否则追究其法律责任。
 */
package com.example.authserver.result.module;

import com.alibaba.fastjson.JSONObject;

/**
 * 
 * 封装和返回Json数据
 * 
 * @author hhlai
 * @version V1.0 
 *
 * @since 2018年1月17日 下午7:05:20
 */
public class JsonResult<T>{

	/**
	 * 请求处理状态
	 */
	private JsonResultStateEnums state;
	/**
	 * 消息文本
	 */
	private Object message;
	//private List<>
	
	/**
	 * 数据正文
	 */
	private T data;
	/**
	 * 
	 * 返回结果的构造
	 * 
	 * @param state  请求结果状态
	 * 
	 * @author hhlai
	 * @since 2018年1月18日 下午1:46:56
	 */
	public JsonResult(JsonResultStateEnums state){
		this.state = state;
	}
	/**
	 * 
	 * 返回结果的构造
	 * 
	 * @param state 请求结果状态
	 * @param data 数据回传
	 * 
	 * @author hhlai
	 * @since 2018年1月18日 下午1:47:58
	 */
	public JsonResult(JsonResultStateEnums state,T data){
		this.state = state;
		setData(data);
	}
	/**
	 * 
	 * 返回结果的构造
	 * 
	 * @param state 请求结果状态
	 * @param k 消息体
	 * @param r 消息体替换变量
	 * 
	 * @author hhlai
	 * @since 2018年1月18日 下午1:48:50
	 */
	public JsonResult(JsonResultStateEnums state,I18nEnums k,Object... r){
		this.state = state;
		setMessage(k,r);
	}
	/**
	 * 
	 * 返回结果的构造
	 * 
	 * @param state 请求结果状态
	 * @param message 集成国际化的消息体
	 * 
	 * @author hhlai
	 * @since 2018年1月18日 下午1:49:22
	 */
	public JsonResult(JsonResultStateEnums state,JsonResultMessage message){
		this.state = state;
		setMessage(message);
	}
	/**
	 * 
	 * 返回结果的构造
	 * 
	 * @param state 请求结果状态
	 * @param data 数据回传
	 * @param k 消息体
	 * @param r 消息体替换变量
	 * 
	 * @author hhlai
	 * @since 2018年1月18日 下午1:49:27
	 */
	public JsonResult(JsonResultStateEnums state,T data,I18nEnums k,Object... r){
		this.state = state;
		setData(data);
		setMessage(k,r);
	}
	/**
	 * 
	 * 返回结果的构造
	 * 
	 * @param state 请求结果状态
	 * @param data 数据回传
	 * @param message 集成国际化的消息体
	 * 
	 * @author hhlai
	 * @since 2018年1月18日 下午1:49:32
	 */
	public JsonResult(JsonResultStateEnums state,T data,JsonResultMessage message){
		this.state = state;
		setData(data);
		setMessage(message);
	}
	public JsonResult(JsonResultStateEnums state,T data,JSONObject message){
		this.state = state;
		setData(data);
		this.message = message;
	}

	public void setState(JsonResultStateEnums state){
		this.state = state;
	}

	public int getState() {
		return state.getState();
	}


	public Object getMessage() {
		return message;
	}

	public void setMessage(JsonResultMessage message) {
		this.message = message;
	}
	public void setMessage(I18nEnums k,Object... obj) {
		this.message = new JsonResultMessage(k,obj);
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		if(data instanceof JsonResultMessage
				||data instanceof I18nEnums){
			JsonResultUtils.throwDevelopErrorException("参数类型不允许为JsonResultMessage、I18nEnums。");
		}
		this.data = data;
	}

	
}
