package com.example.authserver.entity.ext;

import com.example.authserver.entity.ClientInfoEntity;

import javax.persistence.Column;
import javax.persistence.Table;

@Table(name = "O_CLIENT_INFO")
public class ClientInfoEntityExt extends ClientInfoEntity {


}
