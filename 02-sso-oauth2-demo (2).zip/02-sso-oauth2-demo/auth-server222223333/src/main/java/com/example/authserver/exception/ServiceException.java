package com.example.authserver.exception;

import com.example.authserver.result.module.I18nEnums;
import com.example.authserver.result.module.JsonResultMessage;


/**
 * 
 * 系统公共的应用级别的错误，引入国际化的枚举类作为参数变量
 * 
 * @author hhlai
 * @version V1.0 
 *
 * @since 2018年1月20日 下午8:58:21
 */
public class ServiceException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JsonResultMessage jsonResultMessage;
	public ServiceException(Throwable e) {
		this.jsonResultMessage = new JsonResultMessage(I18nEnums.default_serviceexception_error);
	}
	/**
	 * 
	 * 
	 */
	public ServiceException() {
		this.jsonResultMessage = new JsonResultMessage(I18nEnums.default_serviceexception_error);
	}
	public ServiceException(I18nEnums i18nMessage,Object... r) {
		this.jsonResultMessage = new JsonResultMessage(i18nMessage, r);
	}
	public ServiceException(JsonResultMessage i18nMessage) {
		this.jsonResultMessage = i18nMessage;
	}
	public JsonResultMessage getJsonResultMessage() {
		return jsonResultMessage;
	}
	
	public JsonResultMessage getJsonResultMessage(JsonResultMessage jsonResultMessage) {
		return jsonResultMessage;
	}
	/**
	*
	* 
	* @return
	* @see Throwable#getMessage()
	* 
	* @version V2.0.0
	* @author hhlai
	* @date 2018年1月23日 下午12:54:31
	* 
	* @modifyDesc: (这里填写修改说明)
	* @modifyAuthor: (这里填写最近修改人)
	* @modifyDate: (这里填写最近修改时间)
	* 
	*/
	@Override
	public String getMessage() {
		String message = super.getMessage();
		return getJsonResultMessage().toString()+(message==null?"":("\n"+message));
	}
	

}
