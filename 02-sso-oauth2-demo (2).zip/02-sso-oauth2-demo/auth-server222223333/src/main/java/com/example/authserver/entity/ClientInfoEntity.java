package com.example.authserver.entity;

import javax.persistence.Column;
import javax.persistence.Table;

@Table(name = "O_CLIENT_INFO")
public class ClientInfoEntity {

    @Column(name = "CLIENT_ID")
    private String clientId;
    @Column(name = "CLIENT_NAME")
    private String clientName;

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }
}
