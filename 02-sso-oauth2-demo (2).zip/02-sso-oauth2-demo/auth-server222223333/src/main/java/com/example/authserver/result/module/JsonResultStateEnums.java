package com.example.authserver.result.module;


/**
 * 
 * 请求结果状态
 * 
 * @author hhlai
 * @version V1.0 
 *
 * @since 2018年1月18日 下午1:47:23
 */
public enum JsonResultStateEnums {
	/** 
	 * 成功
	 * 
	 * @Fields SUCCESS
	 * @author hhlai
	 * @since 2018年1月19日 下午7:00:26
	*/ 
	SUCCESS(200),
	/** 
	 * 失败
	 * 
	 * @Fields ERROR
	 * @author hhlai
	 * @since 2018年1月19日 下午7:00:26
	*/ 
	ERROR(207),
	/**
	 * 301 rewrite
	 */
	FOUND(302),
	/** 
	 * 无访问权限
	 * 
	 * @Fields FORBIDDEN
	 * @author hhlai
	 * @since 2018年1月19日 下午7:00:26
	*/ 
	FORBIDDEN(401),
	/** 
	 * 未登录
	 * 
	 * @Fields NO_LOGON
	 * @author hhlai
	 * @since 2018年1月19日 下午7:00:26
	*/ 
	NO_LOGIN(403),
	/** 
	 * 服务器异常
	 * 
	 * @Fields EXCEPTION
	 * @author hhlai
	 * @since 2018年1月19日 下午7:00:26
	*/ 
	EXCEPTION(500)
	;
	private int state;
	
	/**
	 * 
	 */
	private JsonResultStateEnums(int state) {
		this.state = state;
	}

	public int getState() {
		return state;
	}
	public static JsonResultStateEnums getByState(int state) {
		for (JsonResultStateEnums v : JsonResultStateEnums.values()) {
			if(v.getState() == state){
				return v;
			}
		}
		
		return null;
	}
	
}
