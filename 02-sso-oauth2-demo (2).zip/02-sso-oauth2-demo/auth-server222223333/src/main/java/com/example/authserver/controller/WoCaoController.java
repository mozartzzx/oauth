package com.example.authserver.controller;

import com.example.authserver.entity.UserEntity;
import com.example.authserver.result.module.JsonResult;
import com.example.authserver.result.module.JsonResultUtils;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "wocao")
public class WoCaoController {
        @RequestMapping(value = "info")
        public JsonResult me( ) {
            SecurityContext context = SecurityContextHolder.getContext();
            Authentication authentication = context.getAuthentication();

            UserEntity userEntity = new UserEntity();
            userEntity.setUsername(authentication.getName());
            userEntity.setName(authentication.getName());
            return JsonResultUtils.getJsonResultSuccess(userEntity);
        }

}

