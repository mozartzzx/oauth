package com.example.authserver.exception;

/**
 * 
 * 系统公共的应用级别的错误，引入国际化的枚举类作为参数变量
 * 
 * @author hhlai
 * @version V1.0 
 *
 * @since 2018年1月20日 下午8:58:21
 */
public class RemoteServiceException extends ServiceException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String jsonResult;

	public RemoteServiceException(String jsonResult) {
		this.jsonResult = jsonResult;
	}

	/**  
	 * TODO(这里用一句话描述这个方法的作用)
	 * @return: JsonResult
	 */
	public String getJsonResult() {
		return jsonResult;
	}

	
	@Override
	public String getMessage() {
		return getJsonResult();
	}
}
