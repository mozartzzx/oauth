package com.example.authserver.exception;


import com.example.authserver.result.module.JsonResultMessage;

public class ApiCallException extends ServiceException {
    public ApiCallException() {
        super();
    }

//    public ApiCallException(String message) {
//        super(message);
//    }
    public ApiCallException(JsonResultMessage jsonResultMessage){
        super(jsonResultMessage);
    };

    public ApiCallException(Exception e) {
        super(e);
    }
}
