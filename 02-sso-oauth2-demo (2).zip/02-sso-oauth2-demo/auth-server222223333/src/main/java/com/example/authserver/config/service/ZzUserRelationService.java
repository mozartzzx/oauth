package com.example.authserver.config.service;

import com.example.authserver.ifmsEncrypt.PasswordEncypt;
import com.zzxdefault.security.service.UserRelationService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component
public class ZzUserRelationService implements UserRelationService {
    @Resource
    private JdbcTemplate jdbcTemplate;


    private  String queryuser = "SELECT C_PASSWORD,C_USERNAME FROM SYS_USER WHERE C_USERNAME = ? ";

    public UserDetails loadUserByUsername(String username) {



        List<Map<String, Object>> maps = jdbcTemplate.queryForList(queryuser, username);
        if(maps==null||maps.size()==0){
           throw new  UsernameNotFoundException("用户名或密码错误");
        }
        if(maps.size()>1){
            throw new  UsernameNotFoundException("用户名或密码错误");
        }

        String c_password = maps.get(0).get("C_PASSWORD").toString();

        return new User(username,c_password,new ArrayList());
    }

    public String encrypt(String password) {
        return PasswordEncypt.encrypt(password);
    }

    public boolean matchePassword(String encodedPassword, String rawPasswordEncoded) {
        return StringUtils.equals(encodedPassword,rawPasswordEncoded);
    }
}
