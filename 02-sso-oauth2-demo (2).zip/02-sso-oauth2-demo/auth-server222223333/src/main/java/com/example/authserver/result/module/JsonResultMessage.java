/**
 * Copyright (c) 2018. www.sunnyintell.com Inc. All rights reserved.
 * 注意：本内容仅限于宁波舜宇智能科技有限公司内部传阅，禁止外泄以及用于其他的商业目的。否则追究其法律责任。
 */
package com.example.authserver.result.module;

import com.alibaba.fastjson.JSONObject;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 
 * 集成多语言的消息体
 * 
 * @author hhlai
 * @version V1.0 
 *
 * @since 2018年1月17日 下午7:05:20
 */
public class JsonResultMessage{
	/**
	 * 主消息提示
	 */
	private I18nEnums k;
	private String ps;
	public String getPs() {
		return ps;
	}

	public void setPs(String ps) {
		this.ps = ps;
	}
	/**
	 * 替换站位符
	 */
	private List<Object> r;
	/**   
	 *
	 * 
	 * 
	 * @author hhlai
	 * @since 2018年1月18日 上午10:34:51
	 */
	public JsonResultMessage(I18nEnums k,Object... r) {
		this.k = k;
		setR_Safe(r);
	}
	
	public JsonResultMessage(I18nEnums k,List r) {
		this.k = k;
		setR_Safe(r);
	}
	public String getK() {
		return k==null?"":k.getKey();
	}
	
	public void setK(I18nEnums k) {
		this.k = k;
	}
	/**
	 * 
	* 目前兼容I18nEnums、String、Integer、BigDecimal
	* <br>安全校验的传值
	*
	* @param r 传入对象可为 I18nEnums、String、Integer、BigDecimal
	* 
	* @author hhlai
	* @version V1.0
	* 
	* @since 2018年1月18日 下午1:27:21
	 */
	public void setR_Safe(Object... r) {
		if(k==null||k.getReplaceNum() != r.length){
			JsonResultUtils.throwDevelopErrorException("要求的多语言模板参数为"+k.getReplaceNum()+"，实际模板参数为"+r.length+"."
					+"\nPs:考虑以下情况："
					+ "\n1、JsonResultUtils.getJsonResultSuccess(data, i18nMessage),回传的参数data应该在I18nEnums前面。"
					+"\n by hhlai");
		}
		List<Object> objs = Arrays.asList(r);
		for(Object obj:objs){
			if(!(obj == null
					||obj instanceof I18nEnums
					||obj instanceof String
					||obj instanceof Integer
					||obj instanceof BigDecimal)){
				JsonResultUtils.throwDevelopErrorException("要求的多语言模板参数类型为I18nEnums、String、Integer、BigDecimal，其它不允许。");
			}
		}
		this.r = objs;
	}
	
	public void setR_Safe(List r) {
		if(k==null||k.getReplaceNum() != r.size()){
			JsonResultUtils.throwDevelopErrorException("要求的多语言模板参数为"+k.getReplaceNum()+"，实际模板参数为"+r.size()+"."
					+"\nPs:考虑以下情况："
					+ "\n1、JsonResultUtils.getJsonResultSuccess(data, i18nMessage),回传的参数data应该在I18nEnums前面。"
					+"\n by hhlai");
		}
		List<Object> objs = r;
		for(Object obj:objs){
			if(!(obj == null
					||obj instanceof I18nEnums
					||obj instanceof String
					||obj instanceof Integer
					||obj instanceof BigDecimal)){
				JsonResultUtils.throwDevelopErrorException("要求的多语言模板参数类型为I18nEnums、String、Integer、BigDecimal，其它不允许。");
			}
		}
		this.r = objs;
	}
	/**
	 * 
	* 无安全校验的传值
	* 
	* @param r
	* 
	* @version V2.0.0
	* @author hhlai
	* @date 2018年1月30日 下午12:28:27
	* 
	* @modifyDesc: (这里填写修改说明)
	* @modifyAuthor: (这里填写最近修改人)
	* @modifyDate: (这里填写最近修改时间)
	*
	 */
	public void setR(Object... r) {
		List<Object> objs = Arrays.asList(r);
		for(Object obj:objs){
			if(!(obj instanceof I18nEnums
					||obj instanceof String
					||obj instanceof Integer
					||obj instanceof BigDecimal)){
				JsonResultUtils.throwDevelopErrorException("要求的多语言模板参数类型为I18nEnums、String、Integer、BigDecimal，其它不允许。");
			}
		}
		this.r = objs;
	}
	public List<Object> getR() {
		List<Object> result = new ArrayList<Object>();
		for(Object obj:r){
			if(obj instanceof I18nEnums){
				result.add(((I18nEnums)obj).getKey());
			}else{
				result.add(obj);
			}
		}
		return result;
	}
	/**
	*
	* 
	* @return
	* @see Object#toString()
	* 
	* @version V2.0.0
	* @author hhlai
	* @date 2018年1月23日 下午12:55:40
	* 
	* @modifyDesc: (这里填写修改说明)
	* @modifyAuthor: (这里填写最近修改人)
	* @modifyDate: (这里填写最近修改时间)
	* 
	*/
	@Override
	public String toString() {
		
		String json = JSONObject.toJSONString(this);
		this.ps=k.getDesc();
		json = json +"\nps:"+ (k == null?"":k.getDesc());
		int index=0;
		for (Object obj : r) {
			try {
				if(obj instanceof I18nEnums){
					json += ","+((I18nEnums)obj).getDesc();
					ps+=","+((I18nEnums)obj).getDesc();
				}else{
					json += ","+obj;
					ps=ps.replaceAll("\\{"+index+"\\}", obj == null?"":obj.toString());
					index++;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		return json;
	}
	public static void main(String[] args) {
		//JsonResultMessage jr = new JsonResultMessage(I18nEnums.msg_error_value_repeat,I18nEnums.sysUser_C_STAFFNUMB);
		//jr.setData(null);
		//System.out.println(JSON.toJSONString(jr));
		
	}
	/**   
	 * TODO(这里用一句话描述这个方法的作用)
	 * 
	 * 
	 * @author xulb
	 * @since 2018年3月31日 下午5:49:49
	 */
	public JsonResultMessage() {
		// TODO Auto-generated constructor stub
	}
}
