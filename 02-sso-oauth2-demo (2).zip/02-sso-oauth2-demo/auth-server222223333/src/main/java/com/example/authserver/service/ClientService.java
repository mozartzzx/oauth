package com.example.authserver.service;

import com.example.authserver.dao.ClientDao;
import com.example.authserver.dao.ClientInfoDao;
import com.example.authserver.entity.ext.ClientEntityExt;
import com.example.authserver.entity.ext.ClientInfoEntityExt;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.List;

@Component
public class ClientService {

    @Resource
    private ClientDao clientDao;
    @Resource
    private ClientInfoDao  clientInfoDao;


    public List<ClientEntityExt> infolist() {

        return  clientDao.selectlist();
    }

    public void addClient(ClientEntityExt clientEntityExt) {
        ClientInfoEntityExt clientInfoEntityExt = new ClientInfoEntityExt();
        clientInfoEntityExt.setClientId(clientEntityExt.getClientId());
        clientInfoEntityExt.setClientName(clientEntityExt.getClientName());
        clientInfoDao.insertSelective(clientInfoEntityExt);
        clientDao.insertSelective(clientEntityExt);


    }

    public void deleteClients(List<ClientEntityExt> clientEntityList) {

            if(CollectionUtils.isEmpty(clientEntityList)){
                return;
            }
        ClientEntityExt d = new ClientEntityExt();

            for (ClientEntityExt dd: clientEntityList){
                d.getClientIds().add(dd.getClientId());
            }
        clientDao.deletein(d);
        clientDao.deleteinfoin(d);

    }

    public void updateClient(ClientEntityExt clientEntity) {

        clientDao.updatebyclientid(clientEntity);
        clientDao.updateinfobyclientid(clientEntity);
    }
}
