package com.example.authserver.ifmsEncrypt;

/**
 * @author yjweng
 * @version 1.0
 *  密码加密类
 */
public class PasswordEncypt {
    /**
     * @param password 明文密码
     * @return 密文密码
     * @throws Exception 抛出异常 NoSuchAlgorithmException,UnsupportedEncodingException
     */
    public static String encrypt(String password) {
        try {
            return Encrypt.encryptByMD5(Encrypt.encryptByBase64(password));
        } catch (Exception e) {

        }
        return "";
    }

}
