package com.example.clienta.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 获取页面的接口
 * @author zfh
 * @version 1.0
 * @since 2019/6/14 13:58
 */
@Controller
public class IndexAction {


    @GetMapping(value = "")
    public String index() {
        System.out.println("进入ClientA首页");
        return "index.html";
    }
    @GetMapping(value = "qq/{id}")
    @ResponseBody
    @Cacheable(value ="indexqq", key = "#id" ,sync = true)
    public String indexqq(@PathVariable("id") String id) {
        return id+"index.html";
    }
    @GetMapping(value = "del/{id}")
    @CacheEvict(value ="indexqq", key = "#id" ,beforeInvocation = true)
    public String del(@PathVariable("id") String id) {
        return id+"del.html";
    }

    @GetMapping(value = "securedPage")
    public String home() {
        System.out.println("进入ClientA securedPage");
        return "securedPage.html";
    }
}
