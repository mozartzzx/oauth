package com.example.clienta.config;

import com.zzxdefault.oauth2.sso.config.ZcAbstractOauth2ManagerConfiguration;
import com.zzxdefault.oauth2.sso.config.ZcOauth2ManagerBuilder;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MyOauth2ManagerConfig extends ZcAbstractOauth2ManagerConfiguration {

    protected void configer(ZcOauth2ManagerBuilder zcOauth2ManagerBuilder) {
        zcOauth2ManagerBuilder.successForwardUrl("/securedPage");
        zcOauth2ManagerBuilder.failureForwardUrl("/");
        /*OAuth2ClientAuthenticationProcessingFilter qq = zcOauth2ManagerBuilder.getFilter("qq");
        qq.setAuthenticationSuccessHandler(new AuthenticationSuccessHandler(){

            public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
                System.out.println("自定义 onAuthenticationSuccess");

            }
        });
        /*ResourceServerTokenServices qq1 = zcOauth2ManagerBuilder.getTokenServices("qq");
        if(qq1 instanceof UserInfoTokenServices){
            UserInfoTokenServices UserInfoTokenServices = (UserInfoTokenServices)qq1;
            UserInfoTokenServices.setPrincipalExtractor(new PrincipalExtractor(){

                private   final String[] PRINCIPAL_KEYS = new String[] { "user", "username",
                        "userid", "user_id", "login", "id", "name" };


                public Object extractPrincipal(Map<String, Object> map) {
                    System.out.println("自定义 extractPrincipal");
                    for (String key : PRINCIPAL_KEYS) {
                        if (map.containsKey(key)) {
                            return map.get(key);
                        }
                    }
                    return null;
                }
            });
        }*/

    }
}
