package com.example.redis.config;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

/**
 * springboot 2.0 默认使用 lettuce客户端 连接redis服务器
 *
 * lettuce 是基于 netty
 * 		而 netty 是一个 多线程，事件驱动的I/O框架；
 * 		所以即使lettuce在不使用连接池的情况下，他的一个实例 也是 可以被多线程共享，是线程安全的，不用担心多线程并发问题
 * 		当然 他也可以使用连接池
 *
 * 而 jedis 实现上是 直接连redis server的，是线程不安全的，
 * 		如果想要在多线程场景下使用jedis，就必须使用连接池，让每个线程都使用自己的jedis实例；
 * 		连接数增多，会消耗更多的资源
 *
 * 配置
 * 		redis:
 *     cluster:
 *       nodes: ${redis.host.cluster}
 *     password: ${redis.password}
 *     lettuce:
 *       shutdown-timeout: 100 # 关闭超时时间
 *       pool:
 *         max-active: 8 # 连接池最大连接数（使用负值表示没有限制）
 *         max-idle: 8 # 连接池中的最大空闲连接
 *         max-wait: 30 # 连接池最大阻塞等待时间（使用负值表示没有限制）
 *         min-idle: 0 # 连接池中的最小空闲连接
 * 同时，使用连接池，要依赖commons-pool2
 *
 * <dependency>
 *             <groupId>org.apache.commons</groupId>
 *             <artifactId>commons-pool2</artifactId>
 *  </dependency>
 *
 *
 *  redis:
 *     cluster:
 *       nodes: ${redis.host.cluster}
 *     password: ${redis.password}
 *     jedis:
 *       pool:
 *         max-active: 8 # 连接池最大连接数（使用负值表示没有限制）
 *         max-idle: 8 # 连接池中的最大空闲连接
 *         max-wait: 30 # 连接池最大阻塞等待时间（使用负值表示没有限制）
 *         min-idle: 0 # 连接池中的最小空闲连接
 *
 * 当然你也可以不配置，走默认的连接池配置，但是有一点要注意
 *
 * 		<dependency>
 * 			<groupId>org.springframework.boot</groupId>
 * 			<artifactId>spring-boot-starter-data-redis</artifactId>
 * 			<exclusions>
 * 				<exclusion>
 * 					<groupId>io.lettuce</groupId>
 * 					<artifactId>lettuce-core</artifactId>
 * 				</exclusion>
 * 			</exclusions>
 * 		</dependency>
 *
 * 		<dependency>
 * 			<groupId>redis.clients</groupId>
 * 			<artifactId>jedis</artifactId>
 * 		</dependency>
 * 依赖包的引用里，要去掉lettuce，并且加上jedis的依赖包，否则都是走的lettuce客户端
 *
 * 同时jedis的客户端默认增加了pool的连接池依赖包，所以Jedis默认你配置与否都会有连接池，而lettuce则需要配置文件中配置一下
 */
@ConditionalOnProperty(prefix = "ifms.redis", name = "enabled", havingValue = "true", matchIfMissing = true)
@Configuration
@EnableCaching
public class RedisConfig {

	@Bean
	@Primary
	public RedisTemplate redisTemplate(RedisConnectionFactory redisConnectionFactory) {
		RedisTemplate template = new RedisTemplate();
		template.setConnectionFactory(redisConnectionFactory);
		template.setKeySerializer(new StringRedisSerializer());
		return template;
	}

}
