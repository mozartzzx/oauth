package com.zzxdefault.authorizationserver.tokenstore;

import org.springframework.security.oauth2.provider.token.AccessTokenConverter;
import org.springframework.security.oauth2.provider.token.store.redis.RedisTokenStore;

public abstract class TokenStoreManager {

    public abstract void configer(RedisTokenStore redisTokenStore);
    public abstract AccessTokenConverter getAccessTokenConverter();
}
